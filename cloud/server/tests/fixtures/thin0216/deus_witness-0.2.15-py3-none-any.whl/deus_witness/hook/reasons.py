"""Reason code -> text a person understands (hook messages; the same table is in docs/coverage.md, a test keeps them equal).

`kind` is the decision the code comes with: deny (the call is blocked, no question) or ask (the owner is asked in Witness).
A wire tool of the hook (`Bash.danger`, `Bash.write`, `Bash.net`, `Read.secret`, `Grep.secret`) can refine an `ask`: the core names the
class of the call, the person needs the real thing. Since PROPOSAL-06 (preset 0.3) a shell command is its own class `command`, with
its own codes ESCALATE_COMMAND / ESCALATE_COMMAND_DANGER; an agent created before keeps its -05 tool map, where a dangerous command
is judged like publishing (ESCALATE_PUBLISH), and the refinement below still names the real thing for it."""
from __future__ import annotations

# code: (kind, text)
REASONS = {
    # ask (core verdict defer)
    "ESCALATE_PUBLISH": ("ask", "this action leaves the machine or is hard to undo and the mandate lists no channel for it: the owner decides"),
    "ESCALATE_DELETE": ("ask", "a deletion the mandate does not cover: the owner decides"),
    "ESCALATE_MONEY": ("ask", "a payment the mandate does not settle by itself (above the limit asked, or no price): the owner decides"),
    "ESCALATE_DATA": ("ask", "the call may carry protected data: the owner decides"),
    "ESCALATE_FILE": ("ask", "a file action the mandate does not cover: the owner decides"),
    "ESCALATE_COUNT": ("ask", "too many actions of this kind in a short time: the owner decides"),
    "ESCALATE_COMMAND": ("ask", "a shell command that is not on the owner's list of commands that run without a question: the owner decides, in Witness (not in this window)"),
    "ESCALATE_COMMAND_DANGER": ("ask", "a dangerous shell command (recursive delete, disk tools, force-push, a download piped into a shell, credentials ...): no list covers it, the owner decides each time, in Witness (not in this window)"),
    "ESCALATE_EXEC_CHANGED": ("ask", "a file this command executes (conftest.py, package.json, Makefile, build.rs, .git/hooks ...) changed since the owner last confirmed it: the list and project permissions do not cover it, the owner decides once, in Witness (the page names the file)"),
    # deny
    "APPROVER_NONE": ("deny", "this agent's actions are confirmed by other people of the team (delegation), and nobody who may confirm this one is available: it is blocked, not let through"),
    "RESOURCE": ("deny", "the target is outside what the owner's mandate allows (writes: only inside the project)"),
    "IRREVERSIBLE_DELETE": ("deny", "the mandate does not allow overwriting or deleting files that cannot be restored"),
    "RECIPIENT": ("deny", "this domain or recipient is not in the owner's mandate"),
    "TOOL_UNMAPPED": ("deny", "this tool is not in the agent's tool map in Witness; the owner can add it"),
    "TOOL_ARGS_UNMAPPED": ("deny", "the call has an argument the tool map does not describe; the owner can map it"),
    "NO_MANDATE": ("deny", "the owner has not signed a mandate for this agent yet"),
    "DATA_NOT_PERMITTED": ("deny", "the call carries protected data (a secret or a listed pattern)"),
    "DATA_FORBIDDEN": ("deny", "the call carries data the mandate forbids"),
    "REFUSED": ("deny", "the owner refused this action within the last hour"),
    "APPROVAL_REFUSED": ("deny", "the owner refused this action in Witness"),
    "TOOLMAP_CHANGED": ("deny", "the tool map changed after the mandate was signed; the owner must sign again"),
    "CLASS_DENIED": ("deny", "the owner's mandate forbids this kind of action"),
    "CLASS_UNKNOWN": ("deny", "the witness does not know this kind of action"),
    "BUDGET": ("deny", "the 24-hour budget of the mandate is used up"),
    "PER_ACTION_LIMIT": ("deny", "the amount is above the limit of one action in the mandate"),
    "CEILING": ("deny", "the amount is above the ceiling of the mandate"),
    "PRICE": ("deny", "the price does not fit the mandate"),
    "COUNT_LIMIT": ("deny", "too many actions of this kind: the limit of the mandate is reached"),
    "EXPIRED": ("deny", "the mandate has expired; the owner must sign a new one"),
    "RECEIPT_EXPIRED": ("deny", "the owner's approval expired before the call ran"),
    "AGENT_MISMATCH": ("deny", "the mandate was signed for another agent"),
    "MANDATE_SIG": ("deny", "the mandate's signature is not valid"),
    "BAD_AMOUNT": ("deny", "the amount in the call is not valid"),
    "UNATTENDED_MEETING": ("deny", "this needs the owner present"),
    # hook-side (before or around the witness)
    "RESERVED_KEY": ("deny", "the tool input carries the reserved key `_witness`"),
    "EVENT_MALFORMED": ("deny", "Claude Code sent an event the hook cannot read"),
    "EVENT_TOO_LARGE": ("deny", "the tool call is too large to be judged"),
    "WITNESS_NOT_CONFIGURED": ("deny", "the hook has no agent key (set DEUS_WITNESS_KEY)"),
    "WITNESS_UNAVAILABLE": ("deny", "the witness cannot be reached; the call does not run without it"),
    "WITNESS_TIMEOUT": ("deny", "the witness did not answer in time; the call does not run without it"),
    "WITNESS_KEY_CHANGED": ("deny", "the witness key is not the one pinned on this machine"),
    "REQUEST_MISMATCH": ("deny", "the receipt is for a different call than the one being run"),
    "HOOK_ERROR": ("deny", "the hook failed; the call does not run (fail-closed)"),
}

# what a wire tool of the hook means for a person: only for the codes the core really gives for that class of call (under a -05 tool map a dangerous
# command is judged like a publication; a shell write/delete like a deletion). ESCALATE_COMMAND* need no refinement: their own text is the real thing. Any other ask code (ESCALATE_COUNT, ESCALATE_DATA ...) is explained by its own table entry (R5-06).
TOOL_CODES = {"Bash.danger": {"ESCALATE_PUBLISH"}, "Write.danger": {"ESCALATE_PUBLISH", "ESCALATE_COMMAND_DANGER"}, "Bash.net": {"ESCALATE_PUBLISH"}, "Read.secret": {"ESCALATE_PUBLISH", "ESCALATE_FILE", "ESCALATE_DATA"},
              "Bash.write": {"ESCALATE_DELETE", "ESCALATE_FILE"}, "Grep.secret": {"ESCALATE_PUBLISH", "ESCALATE_FILE", "ESCALATE_DATA"},
              "NotebookRead.secret": {"ESCALATE_PUBLISH", "ESCALATE_FILE", "ESCALATE_DATA"}}
# what a wire tool of the hook means for a person (only for `ask` codes; the code itself stays visible)
TOOL_ASK = {
    "Bash.danger": "a dangerous shell command (recursive delete, force-push, a download piped into a shell, credentials ...): the owner decides each time, in Witness (not in this window)",
    "Bash.write": "a shell command that writes or deletes files",
    "Bash.net": "a shell command that talks to the network",
    "Read.secret": "reading a credential file",
    "Grep.secret": "searching a credential file (Grep prints the lines it finds)",
    "NotebookRead.secret": "reading a credential file",
    "Write.danger": "a write to git's configuration or hooks (.git/config, .git/hooks, a .git file): git would run the programs named there on a later git command, so the owner decides each time, in Witness (not in this window)",
}


def explain(code: str, tool: str | None = None) -> str:
    """-> text for a person; the table entry, refined by the wire tool for an ask code; '' for an unknown code."""
    kind, text = REASONS.get(code, ("", ""))
    if kind == "ask" and tool in TOOL_ASK and code in TOOL_CODES.get(tool, ()):
        return TOOL_ASK[tool]
    return text


def kind_of(code: str) -> str:
    return REASONS.get(code, ("", ""))[0]
