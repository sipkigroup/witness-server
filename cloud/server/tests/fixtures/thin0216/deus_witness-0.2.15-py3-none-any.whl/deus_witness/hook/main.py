"""deus-witness-hook: Claude Code PreToolUse hook. Every matched tool call goes through the witness before it runs.

  stdin   the PreToolUse event (JSON: tool_name, tool_input, cwd, ...)
  stdout  {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": allow|deny|ask, "permissionDecisionReason": ...}}
  exit    0 always when a decision was printed; 2 (= Claude Code blocks the call) if even that failed

Fail-closed, three layers (see failsafe.py): the hook answers `deny` on every error it can catch; settings.json runs it as
`deus-witness-hook || exit 2` (a missing or broken install = exit 2 = block); and the entry carries `"onFailure": "block"`
(Claude Code 2.1.295+: a timeout, crash or bad output of the hook blocks the call). `--doctor` / the SessionStart hook
(`--session-start`) warn loudly when a layer is missing or Claude Code is too old to honour it.

Witness verdict -> Claude Code decision
  allow (receipt verified, consumed in the ledger)  -> allow   (0.2.10: also OK_ALLOWANCE, an owner-signed project allowance)
  pass  (class pass: not witnessed)                 -> no decision: Claude Code's own permission rules apply
  defer (owner approval pending)                    -> ask (default) | deny | defer   (DEUS_WITNESS_HOOK_ON_DEFER)
  deny / refused / expired / any error / timeout    -> deny with the reason

Env: DEUS_WITNESS_KEY (required), DEUS_WITNESS_URL, DEUS_WITNESS_HOME (key pin dir),
     DEUS_WITNESS_HOOK_TIMEOUT  seconds for the whole decision, default 20, at most 900 (keep it at least 5 s BELOW the hook
                                `timeout` in settings.json: a hook that Claude Code cancels for time gives no decision),
     DEUS_WITNESS_HOOK_WAIT     seconds to wait for the owner on defer before answering, default 0, cut to TIMEOUT - 5
                                (to wait the whole approval window: WAIT 600, TIMEOUT 610, settings `timeout` 620),
     DEUS_WITNESS_HOOK_ON_DEFER ask | deny | defer, default ask (defer: print mode / Agent SDK only - interactive Claude Code
                                ignores it),
     DEUS_WITNESS_HOOK_ALLOW    allow | neutral, default allow (neutral: a witnessed allow still goes through Claude Code's prompts),
     DEUS_WITNESS_VERIFY=0      do not check receipts (not recommended).
The log (stderr) carries the tool, rid and verdict only - never arguments.

  deus-witness-hook --print-form PROJECT_DIR    the recommended mandate form (default rules) as JSON; paste it into the Mandate page
                                                ("Import from JSON"), which shows what will be signed
  deus-witness-hook --doctor [PROJECT_DIR]      is the hook fail-closed here? (Claude Code version, settings.json); exit 1 if not
  deus-witness-hook --session-start             for a SessionStart hook: a loud warning when the hook can be bypassed
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time

from .. import __version__
from . import failsafe
from ..client import AARError, Witness, WitnessError, WitnessKeyChanged, args_sha256
from .mapping import Refuse, default_form, map_event
from .reasons import REASONS, explain

MAX_EVENT = 16 * 1024 * 1024
VERSION = __version__
HINTS = {k: v[1] for k, v in REASONS.items() if v[0] == "deny"}   # kept for callers; the table is reasons.py (and docs/coverage.md)


def log(msg: str) -> None:
    try:
        sys.stderr.write("[deus-witness-hook] %s\n" % msg)
        sys.stderr.flush()
    except Exception:
        pass


def _why(code, tool) -> str:
    t = explain(str(code), tool)
    return " - " + t if t else ""


def _changed(res) -> str:
    """0.2.13 (PROPOSAL-08): the files that made the command a question, as the witness recorded them in the action."""
    ch = (res.action or {}).get("exec_changed") if isinstance(res.action, dict) else None
    if not isinstance(ch, list) or not ch:
        return ""
    names = [str(x) for x in ch[:5]]
    return " [changed: %s%s]" % (", ".join(names), " ..." if len(ch) > 5 else "")


def decision(kind: str | None, reason: str = "") -> dict:
    if kind is None:
        return {}
    return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": kind, "permissionDecisionReason": reason}}


def deny(code: str, rid: str | None = None, detail: str = "") -> dict:
    hint = HINTS.get(code)
    text = "Blocked by Deus Witness: %s (receipt %s)" % (code, rid or "none")
    if detail:
        text += " %s" % detail
    if hint:
        text += ". " + hint
    return decision("deny", text + ". Do not try to reach the same effect another way.")


class Settings:
    def __init__(self, env=None):
        e = os.environ if env is None else env
        self.timeout = _num(e.get("DEUS_WITNESS_HOOK_TIMEOUT"), 20.0, 1.0, 900.0)
        # the answer must be printed before our own deadline: a wait that eats the whole timeout ends as WITNESS_TIMEOUT
        self.wait = min(_num(e.get("DEUS_WITNESS_HOOK_WAIT"), 0.0, 0.0, 900.0), max(0.0, self.timeout - failsafe.MARGIN_S))
        self.on_defer = e.get("DEUS_WITNESS_HOOK_ON_DEFER", "ask") if e.get("DEUS_WITNESS_HOOK_ON_DEFER", "ask") in ("ask", "deny", "defer") else "deny"
        self.allow = "neutral" if e.get("DEUS_WITNESS_HOOK_ALLOW") == "neutral" else "allow"
        self.verify = e.get("DEUS_WITNESS_VERIFY") != "0"
        self.key = e.get("DEUS_WITNESS_KEY")
        self.url = e.get("DEUS_WITNESS_URL")


def _num(v, default, lo, hi):
    try:
        return max(lo, min(float(v), hi)) if v not in (None, "") else default
    except ValueError:
        return default


def judge(ev, s: Settings, witness: Witness | None = None, deadline: float | None = None) -> dict:
    """One PreToolUse event -> hook output. Never raises: anything unexpected is a deny."""
    deadline = deadline or (time.monotonic() + s.timeout)
    try:
        parts = map_event(ev)
    except Refuse as e:
        log("refused before the witness: %s" % e)
        return deny(str(e))
    if not s.key and witness is None:
        return deny("WITNESS_NOT_CONFIGURED", detail="(set DEUS_WITNESS_KEY)")
    own = witness is None
    w = witness or Witness(s.url, s.key, verify=s.verify, timeout=max(1.0, deadline - time.monotonic()))
    try:
        results = []
        for m in parts:                                   # every aspect of the call is judged; ALL must be allowed
            res = w.act(m.tool, m.args, {"name": "deus-witness-hook", "version": VERSION}, False)
            if res.verdict == "defer" and res.status == "pending_approval" and s.wait > 0:
                end = min(deadline - 1.0, time.monotonic() + s.wait)
                while res.status == "pending_approval" and time.monotonic() < end:
                    res = w.get(res.rid, wait=int(max(1, min(25, end - time.monotonic()))))
                if res.status == "covered":
                    # 0.2.10: the owner answered with "allow in this project" (a signed allowance, not an approval of THIS receipt):
                    # the same call is sent again once and judged under the allowance (a new receipt, OK_ALLOWANCE)
                    res = w.act(m.tool, m.args, {"name": "deus-witness-hook", "version": VERSION}, False)
            log("tool=%s rid=%s verdict=%s status=%s" % (m.tool, res.rid, res.verdict, res.status))
            results.append((m, res))
            if res.verdict == "deny" or res.status in ("refused", "expired"):
                break                                     # the first refusal decides; nothing is consumed
        for m, res in results:
            if res.verdict == "deny":
                return deny(res.reason or "DENIED", res.rid)
            if res.status in ("refused", "expired") or res.verdict not in ("allow", "pass", "defer"):
                return deny({"refused": "APPROVAL_REFUSED", "expired": "RECEIPT_EXPIRED"}.get(res.status, res.reason or res.status or "UNKNOWN"), res.rid)
        pending = [(m, res) for m, res in results if res.verdict == "defer"]
        if pending:
            msg = " ".join("Deus Witness: %s is waiting for the owner's approval in Witness (%s, receipt %s)%s%s: %s ." % (m.summary, r.reason, r.rid, _why(r.reason, m.tool), _changed(r), r.approval_url)
                           for m, r in pending) + " After the owner approves there, retry the SAME call."
            if s.wait > 0:
                msg += " (No answer from the owner within %.0f s.)" % s.wait
            if s.on_defer == "ask":
                return decision("ask", msg + " Answering yes here runs it WITHOUT a witness receipt; the safe answer is No: "
                                "approve in Witness, then retry.")
            return decision(s.on_defer, msg)
        allowed = [(m, res) for m, res in results if res.verdict == "allow"]
        for m, res in allowed:                            # check every receipt BEFORE consuming any
            if res.status not in ("allowed", "approved"):
                return deny(res.reason or res.status, res.rid)
            if (res.action or {}).get("args_sha256") != args_sha256(m.tool, m.args):
                return deny("REQUEST_MISMATCH", res.rid)
            if w.verify:
                w.check(res, sent=(m.tool, m.args))
        for m, res in allowed:
            pr = w.present(res.rid)                       # CONSUME in the ledger BEFORE the tool runs: one receipt, one run
            if pr.get("result") != "accept":
                return deny(str(pr.get("reason", "NOT_ACCEPTED")), res.rid)
        owned = [(m, res) for m, res in allowed if res.reason != "OK_PASS"]   # 0.2.4+: a `pass` call under a signed map is answered allow/OK_PASS WITH a receipt (consumed above); it is still not the mandate's decision
        if not owned or s.allow == "neutral":
            return decision(None)                         # only `pass` parts: Claude Code's own permission rules decide
        return decision("allow", "Deus Witness: allowed by the owner's mandate (%s)" % ", ".join(
            "%s, receipt %s" % (res.reason, res.rid) for _, res in owned))
    except AARError as e:
        log("AAR rejected: %s" % e)
        return deny("AAR_%s" % e)
    except WitnessKeyChanged:
        return deny("WITNESS_KEY_CHANGED")
    except WitnessError as e:
        log("witness error %s %s" % (e.status, e.code))
        return deny("WITNESS_UNAVAILABLE", detail=e.code)
    except Exception as e:      # noqa: BLE001  whatever goes wrong while judging, the call does not run
        log("cannot judge (%s)" % type(e).__name__)
        return deny("HOOK_ERROR", detail=type(e).__name__)
    finally:
        if own:
            try:
                w.close()
            except Exception:
                pass


def run(stdin_bytes: bytes, env=None) -> dict | None:
    """-> the hook output, or None for an event that is not PreToolUse (no decision)."""
    s = Settings(env)
    try:
        if len(stdin_bytes) > MAX_EVENT:
            return deny("EVENT_TOO_LARGE")
        ev = json.loads(stdin_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return deny("EVENT_MALFORMED")
    if isinstance(ev, dict) and ev.get("hook_event_name") not in (None, "PreToolUse"):
        return None
    out = {}
    deadline = time.monotonic() + s.timeout

    def work():
        out["r"] = judge(ev, s, deadline=deadline)
    t = threading.Thread(target=work, daemon=True)
    t.start()
    t.join(s.timeout)
    if "r" not in out:
        log("no decision within %.0f s" % s.timeout)
        return deny("WITNESS_TIMEOUT", detail="(no answer within %.0f s)" % s.timeout)
    return out["r"]


def main(argv=None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["--print-form"]:
        print(json.dumps(default_form(argv[1] if len(argv) > 1 else os.getcwd()), indent=1))
        return
    if argv[:1] == ["--doctor"]:
        r = failsafe.check(argv[1] if len(argv) > 1 else os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd())
        print(failsafe.report_text(r))
        sys.stdout.flush()
        os._exit(1 if r["problems"] else 0)
    if argv[:1] == ["--session-start"]:
        try:                                              # a warning only: it never blocks the session
            raw = sys.stdin.read(MAX_EVENT) if not sys.stdin.isatty() else ""
            ev = json.loads(raw) if raw.strip() else {}
            d = (ev.get("cwd") if isinstance(ev, dict) else None) or os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()
            out = failsafe.session_start_output(failsafe.check(os.environ.get("CLAUDE_PROJECT_DIR") or d))
            if out:
                sys.stdout.write(json.dumps(out, ensure_ascii=False) + "\n")
                log(out["systemMessage"])
        except Exception as e:   # noqa: BLE001
            log("session-start check failed (%s)" % type(e).__name__)
        sys.stdout.flush()
        os._exit(0)
    if argv[:1] in (["-h"], ["--help"]):
        print(__doc__)
        return
    try:
        r = run(sys.stdin.buffer.read(MAX_EVENT + 1))
        if r is not None:
            sys.stdout.write(json.dumps(r, ensure_ascii=False) + "\n")
        sys.stdout.flush()
    except BaseException as e:   # noqa: BLE001  exit 2 is the one non-zero code Claude Code treats as "block"
        try:
            sys.stderr.write("Blocked by Deus Witness: HOOK_ERROR %s\n" % type(e).__name__)
        finally:
            os._exit(2)
    os._exit(0)                  # do not wait for a judging thread stuck on the network


if __name__ == "__main__":
    main()
