"""Claude Code tool call (PreToolUse event) -> the call shown to the witness: (wire tool name, args).

The wire args are the tool_input as Claude Code gave it PLUS one reserved key `_witness` that the hook computes
(absolute path, classified command, web recipient). The server's `claude-code` preset (server/app/toolmap.py) reads only
`_witness.*` for the recipient, so a model cannot steer the judged target through tool_input; a tool_input that already
carries `_witness` is refused before anything is sent.

  Claude Code tool        wire tool       witness class                judged on
                                          (preset 0.3 = PROPOSAL-06; -05 preset in brackets: an agent keeps the map it was created with)
  Bash (no danger)        Bash            command        [pass]        every command id "ls", "git status" (mandate command.allow;
                                                                       none listed -> defer ESCALATE_COMMAND; 0.2.10: or an owner-signed
                                                                       allowance for `_witness.project`, PROPOSAL-07)
  Bash (dangerous)        Bash.danger     command, dangerous [publish] "category:detail" -> defer ESCALATE_COMMAND_DANGER
                                                                       [-05: publish.channels; none -> defer ESCALATE_PUBLISH]
  Bash (writes files)     Bash.write      delete, irreversible        every written path   (mandate delete.targets)
  Bash (network)          Bash.net        disclosure                  "webfetch@<host>"    (mandate message.domains, like WebFetch)
  Write/Edit/MultiEdit    same name       delete, irreversible        realpath of file_path
  NotebookEdit            NotebookEdit    delete, irreversible        realpath of notebook_path
  (any of the four, to git's config / hooks / a `.git` file: plus the part Write.danger = command, dangerous [publish] "git-config:<path>", 0.2.9)
  Read (credential file)  Read.secret     publish                     "secrets:<path>"
  Read                    Read            pass                        -
  WebFetch                WebFetch        disclosure                  "webfetch@<host>"    (mandate message.domains)
  0.2.12 (R7-06): the other built-in tools that read files or send data, in the recommended matcher too
  Grep (a credential file Grep.secret     publish                     "secrets:<path or glob>"  (path or glob names a credential file)
    or glob)
  Grep / Glob / LS        same name       pass                        - (listed in the ledger; Claude Code's Read deny rules apply to them)
  NotebookRead            NotebookRead[.secret], like Read on notebook_path (older Claude Code)
  WebSearch               WebSearch       disclosure                  "websearch@api.anthropic.com" (the query leaves the machine: it is
                                                                       sent through the API to the search provider; message.domains)
  ReadMcpResourceTool /   same name       pass                        - (MCP resources are read by Claude Code itself, not through
    ListMcpResourcesTool                                                 deus-witness-mcp: at least the ledger shows them)
  mcp__server__tool       unchanged       whatever the owner maps     (unmapped -> deny TOOL_UNMAPPED)

0.2.13 (PROPOSAL-08): a Bash line in a project also carries `_witness.exec` = {root, files: {relative path: sha256}, truncated}: the files that
test runners, package managers, make, cargo, go, git ... execute (execfiles.py). The server compares them with the versions the owner last
confirmed; a changed one makes the next command that executes it a question (ESCALATE_EXEC_CHANGED) even when the command is listed or allowed.

One Bash line can be several of danger / write / network at once: map_event then returns one part per aspect (same args,
different wire tool) and the hook allows the line only when EVERY part is allowed. A line without danger always carries the
`Bash` part too (PROPOSAL-06: a redirection into the project must not turn an unlisted command into one nobody is asked about);
a dangerous line does not (the owner is asked about the whole line already).
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import tempfile
from dataclasses import dataclass
from urllib.parse import urlsplit

from . import execfiles
from .bashparse import _abspath, classify, is_git_exec_path, is_secret_path

RESERVED = "_witness"
MAX_WRITES = 32
FILE_TOOLS = {"Write": "file_path", "Edit": "file_path", "MultiEdit": "file_path", "NotebookEdit": "notebook_path"}

# Default WebFetch allow-list of the recommended mandate (message.domains): documentation and package indexes only.
DEFAULT_WEB_DOMAINS = ["localhost", "127.0.0.1", "docs.python.org", "pypi.org", "github.com", "raw.githubusercontent.com", "docs.github.com",
                       "developer.mozilla.org", "www.npmjs.com", "nodejs.org", "docs.anthropic.com", "code.claude.com"]


class Refuse(Exception):
    """The event cannot be shown to the witness in a well-formed shape -> deny without asking it."""


@dataclass
class Mapped:
    tool: str
    args: dict
    summary: str          # one line for logs and messages; never the arguments themselves


def web_recipient(url) -> str:
    """WebFetch target as a mailbox-shaped id the core can match on its domain: webfetch@<host>; "" if there is no host."""
    try:
        host = urlsplit(url).hostname if isinstance(url, str) else None
    except ValueError:
        host = None
    if not host:
        return ""
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        return ""
    return "webfetch@" + host.lower().rstrip(".")


def project_of(cwd: str, env=None) -> str | None:
    """0.2.10: the project a Bash line runs in, for the owner's "allow this command in this project" (PROPOSAL-07). It is what Claude Code
    tells the hook, never what the model writes: CLAUDE_PROJECT_DIR (set by Claude Code for its hooks: the directory the session was
    started in), else the event's `cwd`; as a realpath (a symlinked path names its target). None when the session's cwd is outside it
    (the agent went elsewhere: no project allowance applies there)."""
    e = os.environ if env is None else env
    p = e.get("CLAUDE_PROJECT_DIR")
    p = p if isinstance(p, str) and os.path.isabs(p) else cwd
    try:
        p = os.path.realpath(p)
        c = os.path.realpath(cwd)
    except (OSError, ValueError):
        return None
    try:
        home = os.path.realpath(e.get("HOME") or os.path.expanduser("~"))
    except (OSError, ValueError):
        home = None
    if p == "/" or p == home or len(p) > 1024:
        return None                                   # the whole machine or the whole home directory is not a project
    return p if c == p or c.startswith(p.rstrip("/") + "/") else None


def map_event(ev: dict, home: str | None = None, env=None) -> list:
    """-> [Mapped, ...] (one part; several for a Bash line with more than one aspect). Raises Refuse."""
    m = _map(ev, home, env)
    return m if isinstance(m, list) else [m]


def _map(ev, home, env=None):
    if not isinstance(ev, dict):
        raise Refuse("EVENT_MALFORMED")
    tool, inp = ev.get("tool_name"), ev.get("tool_input")
    inp = {} if inp is None else inp
    if not isinstance(tool, str) or not tool or len(tool) > 200 or not isinstance(inp, dict):
        raise Refuse("EVENT_MALFORMED")
    if RESERVED in inp:
        raise Refuse("RESERVED_KEY")
    cwd = ev.get("cwd") if isinstance(ev.get("cwd"), str) and os.path.isabs(ev.get("cwd")) else os.getcwd()
    home = home or os.path.expanduser("~")
    args = json.loads(json.dumps(inp))              # a plain JSON copy: exactly what is hashed and sent
    if tool == "Bash":
        cmd = inp.get("command")
        if not isinstance(cmd, str):
            raise Refuse("EVENT_MALFORMED")
        project = project_of(cwd, env)
        c = classify(cmd, cwd, home, project=project)
        if len(c.writes) > MAX_WRITES:
            c.add("opaque", "%d write targets" % len(c.writes))
            c.writes = c.writes[:MAX_WRITES]
        net = [web_recipient("http://" + h if ":" not in h else "http://[%s]" % h) or "webfetch@" + h for h in c.net[:MAX_WRITES]]
        args[RESERVED] = {"cwd": cwd, "danger": c.danger, "writes": c.writes, "net": net, "commands": c.heads}
        if project is not None:                     # 0.2.10 (PROPOSAL-07): the project and the commands that left it (no allowance for those)
            args[RESERVED].update(project=project, outside=c.outside)
            ex = execfiles.scan(project) if (env if env is not None else os.environ).get("DEUS_WITNESS_EXEC_SCAN", "1") != "0" else None
            if ex is not None:                      # 0.2.13 (PROPOSAL-08): digests of the files commands execute (conftest.py, package.json ...)
                args[RESERVED]["exec"] = ex
        parts = []
        if c.danger:
            parts.append(Mapped("Bash.danger", args, "Bash: " + ", ".join(sorted({d.split(":", 1)[0] for d in c.danger}))))
        if c.writes:
            parts.append(Mapped("Bash.write", args, "Bash: writes %d path(s)" % len(c.writes)))
        if net:
            parts.append(Mapped("Bash.net", args, "Bash: network to " + ", ".join(n.split("@", 1)[1] for n in net)))
        if not c.danger:
            parts.append(Mapped("Bash", args, "Bash: " + (", ".join(c.heads[:4]) + (" ..." if len(c.heads) > 4 else "") if c.heads else "(no command)")))
        return parts
    if tool in FILE_TOOLS:
        p = inp.get(FILE_TOOLS[tool])
        if not isinstance(p, str) or not p:
            raise Refuse("EVENT_MALFORMED")
        path = _abspath(p, cwd, home)
        if is_git_exec_path(path):                  # 0.2.9: git runs what is written there (core.fsmonitor, hooks, a `.git` gitdir pointer)
            args[RESERVED] = {"path": path, "danger": ["git-config:" + path]}
            return [Mapped(tool, args, "%s %s" % (tool, path)), Mapped("Write.danger", args, "%s: git configuration or hook" % tool)]
        args[RESERVED] = {"path": path}
        return Mapped(tool, args, "%s %s" % (tool, path))
    if tool == "Read":
        return _read_like(tool, inp, args, cwd, home, "file_path")
    if tool == "NotebookRead":                      # older Claude Code; today Read reads notebooks
        return _read_like(tool, inp, args, cwd, home, "notebook_path")
    if tool == "Grep":
        return _grep(inp, args, cwd, home)
    if tool in ("Glob", "LS"):
        p = inp.get("path")
        args[RESERVED] = {"path": _abspath(p, cwd, home) if isinstance(p, str) and p else cwd}
        return Mapped(tool, args, tool)
    if tool == "WebSearch":
        args[RESERVED] = {"recipient": WEBSEARCH}
        return Mapped("WebSearch", args, "WebSearch")
    if tool == "WebFetch":
        r = web_recipient(inp.get("url"))
        args[RESERVED] = {"recipient": r}
        return Mapped("WebFetch", args, "WebFetch " + (r.split("@", 1)[1] if r else "(no host)"))
    return Mapped(tool, args, tool)                 # mcp__* and anything else: judged by the owner's tool map (default deny)


WEBSEARCH = "websearch@api.anthropic.com"
# 0.2.12 (R7-06): names a glob of Grep is tried against: a glob that would pick a credential file is a read of a secret
SECRET_SAMPLES = (".env", ".env.local", ".env.production", ".envrc", ".netrc", ".npmrc", ".pypirc", ".pgpass", ".git-credentials", "credentials",
                  "credentials.json", ".vault-token", "id_rsa", "id_ed25519", "id_ecdsa", "server.pem", "server.key", "cert.p12", "store.jks",
                  "db.kdbx", "secrets.yaml", "secrets.yml", "secret.json", "secrets.toml", "secrets.env", ".terraformrc")


def _read_like(tool, inp, args, cwd, home, key):
    p = inp.get(key)
    if not isinstance(p, str) or not p:
        raise Refuse("EVENT_MALFORMED")
    path = _abspath(p, cwd, home)
    if is_secret_path(path):
        args[RESERVED] = {"path": path, "danger": ["secrets:" + path]}
        return Mapped(tool + ".secret", args, "%s credential file" % tool)
    args[RESERVED] = {"path": path}
    return Mapped(tool, args, tool)


def _glob_hits_secret(g: str) -> bool:
    alts = [g]
    m = re.search(r"\{([^{}]*)\}", g)
    if m:                                           # ripgrep globs take one level of {a,b}
        alts = [g[:m.start()] + a + g[m.end():] for a in m.group(1).split(",")]
    for a in alts:
        last = a.rstrip("/").rsplit("/", 1)[-1]
        if is_secret_path(a) or any(fnmatch.fnmatchcase(n, last) for n in SECRET_SAMPLES) or re.search(r"(^|/)(\.ssh|\.aws|\.gnupg|\.kube|\.docker)(/|$)", a):
            return True
    return False


def _grep(inp, args, cwd, home):
    """0.2.12 (R7-06): Grep prints the lines it finds: grepping a credential file (`pattern: "."`, path .env) is reading it. A path or a glob
    that names one -> Grep.secret (asked, like Read.secret / `cat .env`); a search of a directory is `Grep` (pass): ripgrep skips hidden and
    git-ignored files unless told otherwise, and Claude Code's `Read(...)` deny rules also bind Grep (docs/coverage.md 6)."""
    p, g = inp.get("path"), inp.get("glob")
    if (p is not None and not isinstance(p, str)) or (g is not None and not isinstance(g, str)):
        raise Refuse("EVENT_MALFORMED")
    path = _abspath(p, cwd, home) if p else cwd
    danger = []
    if is_secret_path(path) or (p and is_secret_path(p)):
        danger.append("secrets:" + path)
    if g and _glob_hits_secret(g):
        danger.append("secrets:%s/%s" % (path, g))
    args[RESERVED] = {"path": path, "danger": danger} if danger else {"path": path}
    return Mapped("Grep.secret" if danger else "Grep", args, "Grep credential file" if danger else "Grep")


# Default read-only commands of the recommended mandate (command.allow, PROPOSAL-06), 0.2.9: modelled on Claude Code's own read-only set.
# Deliberately NOT listed: find (-exec, -delete), xargs, sed (-i, `e`), awk (system()), env/printenv (print secrets), make, interpreters,
# package managers, curl/wget: they run other programs or code, write files or send data, so listing them would allow whatever they run.
# A listed name covers only the plain form: `./ls`, `LD_PRELOAD=x ls`, `xargs grep`, `git -c k=v status`, `git log --output=f`, `git branch new`,
# `rg --pre cmd`, `date -s` get another identifier ("<id> [<why>]", bashparse._variants) and are asked. Same list: server/app/toolmap.py
# CC_READONLY_COMMANDS and web/js/mandate_form.js READONLY_COMMANDS (a test keeps the three equal). docs/coverage.md 6.2 explains each entry.
DEFAULT_SAFE_COMMANDS = ["ls", "pwd", "cd", "cat", "head", "tail", "wc", "echo", "grep", "rg", "which", "file", "stat", "du", "df", "date", "uname",
                         "git status", "git log", "git diff", "git show", "git branch"]


def default_form(project_dir: str, web_domains=None, safe_commands=None) -> dict:
    """Recommended mandate form for a Claude Code agent (the 'default rules'):
      - writes (Write/Edit/NotebookEdit/Bash redirections) only inside the project and the temp dir; elsewhere deny RESOURCE;
      - shell commands: the listed read-only commands run, any other is asked (ESCALATE_COMMAND), a dangerous one is always asked
        (ESCALATE_COMMAND_DANGER); Read.secret: no publish permission -> defer ESCALATE_PUBLISH (owner approves);
      - WebFetch only to the listed domains; elsewhere deny RECIPIENT;
      - no purchases."""
    proj = os.path.realpath(project_dir)
    tmp = os.path.realpath(tempfile.gettempdir())
    return {"currency": "USD", "valid_days": 30, "purchase": None,
            "message": {"domains": list(DEFAULT_WEB_DOMAINS if web_domains is None else web_domains), "to": []},
            "forbidden_data": [], "publish": None,
            "delete": {"targets": [proj + "/*", tmp + "/*"], "allow_irreversible": True},
            "command": {"allow": list(DEFAULT_SAFE_COMMANDS if safe_commands is None else safe_commands), "unlisted": "ask"}}
