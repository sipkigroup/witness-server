"""Claude Code PreToolUse hook (deus-witness-hook): Bash/Edit/Write/WebFetch/mcp__* calls go through the witness."""
from .bashparse import Command, classify
from .mapping import Mapped, Refuse, default_form, map_event
from .main import judge, run

__all__ = ["Command", "classify", "Mapped", "Refuse", "map_event", "default_form", "judge", "run"]
