"""0.2.13 (PROPOSAL-08): files that a later command EXECUTES (conftest.py, package.json scripts, Makefile, build.rs, .git/hooks ...).

Why: the owner's list and "allow in this project" let `pytest`, `npm test`, `make` run without a question. Those programs run code from the
project's own files, and the agent can edit them. After such a file changes, the next command that executes it is asked again
(ESCALATE_EXEC_CHANGED), and the approval page names the file.

Two sources, both read by the server (cloud/server/app/execguard.py keeps the SAME tables; a test keeps them equal):
  1. every write the witness judged (Write / Edit / MultiEdit / NotebookEdit / a shell write) to such a path marks it "dirty" on the server;
  2. this module, run by the hook before each shell command in a project, reports the SHA-256 of every such file it finds
     (`_witness.exec` = {root, files: {relative path: sha256 hex}, truncated}); the server compares with the version the owner last
     confirmed. This catches changes the witness did not see as a write (an interpreter, `git checkout`, a test that rewrites conftest.py).
Pure standard library; no imports from the rest of the package (the server test loads this file directly)."""
from __future__ import annotations

import hashlib
import os
import re
import time
import unicodedata

# ---------------------------------------------------------------- which file belongs to which family (what executes it)
# 0.2.14 (R8-01): every name and directory is compared after NFC + casefold (macOS APFS and Windows NTFS open PACKAGE.JSON as package.json),
# trailing dots/spaces dropped (Windows); the tables hold the folded forms. (R8-02): more files of the declared ecosystems; a DIRS rule with
# "**" takes every file below that directory at any depth, "*" only its direct children.
NAMES = {
    # Python: pytest / tox / nox / pip / linters with plugins / the interpreter itself
    "conftest.py": ("py",), "pytest.ini": ("py",), ".pytest.ini": ("py",), "pytest.toml": ("py",), ".pytest.toml": ("py",), "tox.ini": ("py",),
    "tox.toml": ("py",), "setup.cfg": ("py",), "pyproject.toml": ("py",), "setup.py": ("py",), "noxfile.py": ("py",), "sitecustomize.py": ("py",),
    "usercustomize.py": ("py",), "pylintrc": ("py",), ".pylintrc": ("py",), "mypy.ini": ("py",), ".mypy.ini": ("py",), ".flake8": ("py",),
    ".coveragerc": ("py",), "tasks.py": ("py",), "hatch.toml": ("py",),
    # JavaScript: npm / pnpm / yarn lifecycle scripts and settings
    "package.json": ("js",), ".npmrc": ("js",), ".yarnrc": ("js",), ".yarnrc.yml": ("js",), ".pnpmfile.cjs": ("js",), ".pnp.cjs": ("js",),
    ".pnp.loader.mjs": ("js",), "pnpm-workspace.yaml": ("js",),
    # make / just / task
    "makefile": ("make",), "gnumakefile": ("make",), "justfile": ("make",), ".justfile": ("make",),
    # Rust / Go
    "build.rs": ("cargo",), "cargo.toml": ("cargo",), "rust-toolchain": ("cargo",), "rust-toolchain.toml": ("cargo",), "go.mod": ("go",), "go.work": ("go",),
    # JVM: the wrapper scripts execute THEMSELVES (./gradlew, ./mvnw)
    "build.gradle": ("gradle",), "build.gradle.kts": ("gradle",), "settings.gradle": ("gradle",), "settings.gradle.kts": ("gradle",),
    "gradle.properties": ("gradle",), "gradle-wrapper.properties": ("gradle",), "gradlew": ("gradle",), "gradlew.bat": ("gradle",),
    "pom.xml": ("maven",), "mvnw": ("maven",), "mvnw.cmd": ("maven",),
    # git: attributes name filters / diff drivers; pre-commit runs from a git hook
    ".gitattributes": ("git",), ".pre-commit-config.yaml": ("git", "py"),
    # containers, CI, editor tasks
    "dockerfile": ("docker",), "containerfile": ("docker",), "compose.yaml": ("docker",), "compose.yml": ("docker",),
    "devcontainer.json": ("docker", "editor"), ".devcontainer.json": ("docker", "editor"), ".gitlab-ci.yml": ("ci",),
}
PREFIXES = (("taskfile", ("make",)), ("docker-compose", ("docker",)), ("dockerfile.", ("docker",)), (".yarnrc", ("js",)),
            ("jest.config.", ("js",)), ("vitest.config.", ("js",)), ("vite.config.", ("js",)), (".mocharc", ("js",)),
            ("eslint.config.", ("js",)), (".eslintrc", ("js",)), ("babel.config.", ("js",)), (".babelrc", ("js",)),
            ("playwright.config.", ("js",)), ("webpack.config.", ("js",)), ("prettier.config.", ("js",)), (".prettierrc", ("js",)))
SUFFIXES = ((".pth", ("py",)), (".mk", ("make",)))
# by a directory in the path: (directory components, file test, families)
DIRS = ((".git", "config", ("git",)), (".git", "config.worktree", ("git",)), (".git/info", "attributes", ("git",)), (".git/hooks", "*", ("git",)),
        (".husky", "**", ("git",)), (".githooks", "**", ("git",)),
        (".github/workflows", "*", ("ci",)), (".cargo", "config", ("cargo",)), (".cargo", "config.toml", ("cargo",)), (".mvn", "**", ("maven",)),
        ("gradle/wrapper", "*", ("gradle",)), (".vscode", "tasks.json", ("editor",)), ("init.d", "*.gradle", ("gradle",)),
        ("init.d", "*.gradle.kts", ("gradle",)), (".yarn/releases", "*", ("js",)), (".yarn/plugins", "**", ("js",)),
        # the executables of the commands themselves inside the project (an activated virtual environment, npm's .bin) and what they import
        ("node_modules", "**", ("js",)), ("site-packages", "**", ("py",)), (".venv/bin", "*", ("py",)), ("venv/bin", "*", ("py",)),
        (".venv/scripts", "*", ("py",)), ("venv/scripts", "*", ("py",)))

# ---------------------------------------------------------------- which command executes which family
EXECUTORS = {
    "py": ("python", "python2", "python3", "pypy", "pypy3", "pytest", "py.test", "tox", "nox", "pip", "pip3", "mypy", "pylint", "flake8",
           "uv", "uvx", "pipx", "poetry", "hatch", "pdm", "pre-commit", "ipython", "coverage", "invoke", "inv"),
    "js": ("npm", "pnpm", "yarn", "npx", "pnpx", "node", "nodejs", "bun", "bunx", "deno", "jest", "vitest", "mocha", "eslint", "prettier",
           "tsc", "playwright", "webpack", "vite", "tsx", "ts-node", "corepack"),
    "make": ("make", "gmake", "just", "task"),
    "cargo": ("cargo", "rustup"),
    "go": ("go",),
    "gradle": ("gradle", "gradlew"),
    "maven": ("mvn", "mvnw"),
    "git": ("git", "pre-commit", "husky", "lint-staged"),
    "docker": ("docker", "docker-compose", "podman", "devcontainer"),
    "ci": ("act", "gitlab-runner"),
    "editor": ("code", "devcontainer"),
}
SUB_EXECUTORS = {("git", "push"): ("ci",), ("gh", "workflow"): ("ci",), ("gh", "run"): ("ci",)}
_PY_RE = re.compile(r"(python|pypy)[0-9.]*")


def fold(name: str) -> str:
    """0.2.14 (R8-01): the form a case-insensitive file system compares: NFC, casefold, no trailing dots/spaces (Windows)."""
    return unicodedata.normalize("NFC", name).casefold().rstrip(". ") or name


def families_of_path(path: str) -> tuple:
    """-> the families whose commands execute this file (empty: not an executed file). `path` absolute or relative, '/'-separated."""
    p = path.replace("\\", "/").rstrip("/")
    parts = [fold(x) for x in p.split("/") if x]
    if not parts:
        return ()
    name = parts[-1]
    out = set(NAMES.get(name, ()))
    for pre, fam in PREFIXES:
        if name.startswith(pre):
            out.update(fam)
    for suf, fam in SUFFIXES:
        if name.endswith(suf) and len(name) > len(suf):
            out.update(fam)
    dirs = parts[:-1]
    for d, f, fam in DIRS:
        dp = d.split("/")
        n = len(dp)
        if f == "**":
            if any(dirs[i:i + n] == dp for i in range(len(dirs) - n + 1)) and not name.endswith(".sample"):
                out.update(fam)
        elif len(parts) >= n + 1 and parts[-1 - n:-1] == dp:
            if f == "*" and not name.endswith(".sample"):
                out.update(fam)
            elif f.startswith("*.") and name.endswith(f[1:]):
                out.update(fam)
            elif f == name:
                out.update(fam)
    return tuple(sorted(out))


def families_of_command(cid: str) -> tuple:
    """A command identifier as the hook names it ("pytest", "npm test", "python3 -m pytest", "npx jest [fetch]", "./gradlew [path]")
    -> the families of files it may execute."""
    if not isinstance(cid, str) or not cid:
        return ()
    words = cid.split("[", 1)[0].split()
    if not words:
        return ()
    head = fold(words[0].rsplit("/", 1)[-1])
    if head.endswith(".exe") or head.endswith(".cmd") or head.endswith(".bat"):
        head = head[:-4]
    out = set()
    if _PY_RE.fullmatch(head):
        out.add("py")
    for fam, names in EXECUTORS.items():
        if head in names:
            out.add(fam)
    if len(words) > 1:
        out.update(SUB_EXECUTORS.get((head, words[1]), ()))
    if head == "sudo" and len(words) > 1:
        out.update(families_of_command(" ".join(words[1:])))
    return tuple(sorted(out))


# ---------------------------------------------------------------- the scan (hook side)
SKIP_DIRS = {"node_modules", ".venv", "venv", "__pycache__", ".tox", ".nox", ".mypy_cache", ".pytest_cache", ".ruff_cache", "dist", "build",
             "target", ".next", ".cache", ".gradle", ".idea", ".hg", ".svn", "coverage", ".terraform", ".eggs", "site-packages", "bower_components"}
MAX_ENTRIES = 20000
MAX_FILES = 200
MAX_DEPTH = 10
MAX_BYTES = 4 * 1024 * 1024
MAX_SECONDS = 0.5
_GO_LINES = re.compile(rb"^\s*(go|toolchain|replace)\b")


def file_digest(path: str, root: str) -> str:
    """SHA-256 hex of what the file means for execution: its content (go.mod: only the go / toolchain / replace lines, the rest is ordinary
    dependency bookkeeping); a symlink also binds the target's real path (a link swapped to another file is a change). 'unreadable' on error."""
    h = hashlib.sha256()
    try:
        if os.path.islink(path):
            h.update(b"link:" + os.path.realpath(path).encode("utf-8", "surrogateescape") + b"\0")
        with open(path, "rb") as f:
            data = f.read(MAX_BYTES + 1)
        if os.path.basename(path) == "go.mod":
            keep, block = [], False
            for line in data.splitlines():
                s = line.strip()
                if block:
                    keep.append(line)
                    block = s != b")"
                elif _GO_LINES.match(line):
                    keep.append(line)
                    block = s.endswith(b"(")
            data = b"\n".join(keep)
        h.update(data)
        return h.hexdigest()
    except (OSError, ValueError):
        return "unreadable"


_EXEC_NAMES = sorted({n for names in EXECUTORS.values() for n in names})


def _bin_extras(bindir, out, root):
    """0.2.14 (R8-02): the executables of the listed commands inside the project (<venv>/bin/pytest, node_modules/.bin/jest): `pytest`
    with an activated environment, `npm test` -> jest run THESE files. Only names of known commands are read (bounded)."""
    try:
        have = set(os.listdir(bindir))
    except OSError:
        return
    for n in _EXEC_NAMES:
        for v in (n, n + ".exe", n + ".cmd", n + "-script.py"):
            if v in have:
                full = os.path.join(bindir, v)
                out[os.path.relpath(full, root)] = full


def _venv_extras(d, out, root):
    """A virtual environment inside the project: the interpreter runs its site-packages/*.pth and sitecustomize.py at start; its bin/
    holds the commands themselves."""
    for b in ("bin", "Scripts"):
        _bin_extras(os.path.join(d, b), out, root)
    for lib in ("lib", "Lib"):
        base = os.path.join(d, lib)
        try:
            pys = [os.path.join(base, x, "site-packages") for x in os.listdir(base) if x.startswith("python")] if lib == "lib" else [os.path.join(base, "site-packages")]
        except OSError:
            continue
        for sp in pys:
            try:
                names = sorted(os.listdir(sp))
            except OSError:
                continue
            for n in names[:2000]:
                if n.endswith(".pth") or n in ("sitecustomize.py", "usercustomize.py"):
                    full = os.path.join(sp, n)
                    out[os.path.relpath(full, root)] = full


def _git_config_value(path, section, key):
    """The last `key` of `[section]` in a git config file (enough for core.hooksPath; includes are not followed)."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read(MAX_BYTES).splitlines()
    except OSError:
        return None
    cur, val = None, None
    for line in lines:
        t = line.strip()
        if not t or t[0] in "#;":
            continue
        if t.startswith("["):
            cur = t[1:t.find("]")].strip().split()[0].lower() if "]" in t else None
            continue
        if cur == section and "=" in t:
            k, v = t.split("=", 1)
            if k.strip().lower() == key.lower():
                v = v.strip()
                if len(v) >= 2 and v[0] == v[-1] == '"':
                    v = v[1:-1]
                val = v
    return val


def _git_dirs(root):
    """-> (git dir, common git dir) of the working copy at root: `.git` a directory, or a file `gitdir: <path>` (git worktree; Claude Code's
    .claude/worktrees/*) whose `commondir` names the shared .git. (None, None) when root is not a working copy top."""
    g = os.path.join(root, ".git")
    if os.path.isdir(g):
        return g, g
    if not os.path.isfile(g):
        return None, None
    try:
        with open(g, "r", encoding="utf-8", errors="replace") as f:
            line = f.read(4096).strip().splitlines()[0]
    except (OSError, IndexError):
        return None, None
    if not line.startswith("gitdir:"):
        return None, None
    gd = line[len("gitdir:"):].strip()
    gd = os.path.normpath(gd if os.path.isabs(gd) else os.path.join(root, gd))
    common = gd
    try:
        with open(os.path.join(gd, "commondir"), "r", encoding="utf-8", errors="replace") as f:
            cd = f.read(4096).strip()
        if cd:
            common = os.path.normpath(cd if os.path.isabs(cd) else os.path.join(gd, cd))
    except OSError:
        pass
    return (gd, common) if os.path.isdir(gd) else (None, None)


def git_files(root):
    """0.2.14 (R8-04): every file git itself executes or obeys for this working copy, by ABSOLUTE path: config (+ config.worktree),
    info/attributes, hooks/* of the git dir and of the common git dir, and the hooks of core.hooksPath (husky, .githooks), wherever they are."""
    gd, common = _git_dirs(root)
    if gd is None:
        return {}
    out = {}
    for base in dict.fromkeys((gd, common)):
        for rel in ("config", "config.worktree", "info/attributes"):
            p = os.path.join(base, rel)
            if os.path.isfile(p):
                out[p] = file_digest(p, root)
    hooks_dirs = [os.path.join(common, "hooks")]
    hp = None
    for cfg in (os.path.join(gd, "config.worktree"), os.path.join(common, "config")):
        hp = hp or _git_config_value(cfg, "core", "hooksPath")
    if hp:
        hp = os.path.expanduser(hp)
        hooks_dirs.append(os.path.normpath(hp if os.path.isabs(hp) else os.path.join(root, hp)))
    for hd in hooks_dirs:
        try:
            names = sorted(os.listdir(hd))
        except OSError:
            continue
        for n in names[:64]:
            p = os.path.join(hd, n)
            if not n.endswith(".sample") and os.path.isfile(p):
                out[p] = file_digest(p, root)
    return dict(sorted(out.items()))


def _prio(rel):
    """0.2.14 (R8-03): the order in which the bounded report keeps files: an exact name or directory rule first (conftest.py, package.json,
    .git/hooks/*), then a name pattern (*.mk, *.pth, jest.config.*); shallow before deep. The agent's cheap junk (a000.mk ...) cannot push a
    named file out of the report; it can only make the report incomplete, and the server asks about an incomplete report."""
    parts = rel.replace("\\", "/").split("/")
    name = fold(parts[-1])
    named = name in NAMES or any(len(parts) > 1 and fold(parts[-2]) == d.split("/")[-1] for d, f, fam in DIRS)
    return (0 if named else 1, len(parts), rel)


def scan(root: str | None, max_seconds: float = MAX_SECONDS) -> dict | None:
    """-> {"root": root, "files": {relative path: digest}, "git": {absolute path: digest}, "truncated": bool} for every executed file under
    `root` (bounded walk) and git's own files (R8-04), or None. truncated: the walk did not see everything or the report was cut (the server
    then treats the state as unknown and asks)."""
    if not isinstance(root, str) or not os.path.isabs(root) or not os.path.isdir(root):
        return None
    found = {}                                              # relative path -> absolute path
    budget = {"n": 0, "trunc": False, "end": time.monotonic() + max_seconds}
    extras = {}
    stack = [(root, 0)]
    while stack:
        d, depth = stack.pop()
        if time.monotonic() > budget["end"]:
            budget["trunc"] = True
            break
        try:
            it = sorted(os.scandir(d), key=lambda e: e.name)
        except OSError:
            continue
        for e in it:
            budget["n"] += 1
            if budget["n"] > MAX_ENTRIES:
                budget["trunc"] = True
                stack = []
                break
            try:
                is_dir = e.is_dir(follow_symlinks=False)
            except OSError:
                continue
            if is_dir:
                if e.name == ".git":
                    continue
                if os.path.isfile(os.path.join(e.path, "pyvenv.cfg")):
                    _venv_extras(e.path, extras, root)
                    continue
                if e.name == "node_modules":
                    _bin_extras(os.path.join(e.path, ".bin"), extras, root)
                    continue
                if e.name in SKIP_DIRS:
                    continue
                if depth + 1 <= MAX_DEPTH:
                    stack.append((e.path, depth + 1))
                else:
                    budget["trunc"] = True
                continue
            rel = os.path.relpath(e.path, root)
            if families_of_path(rel):
                found[rel] = e.path
    found.update(extras)
    out = {}
    for rel in sorted(found, key=_prio):
        if len(out) >= MAX_FILES:
            budget["trunc"] = True
            break
        out[rel] = file_digest(found[rel], root)
    rep = {"root": root, "files": dict(sorted(out.items())), "truncated": bool(budget["trunc"])}
    g = git_files(root)
    if g:
        rep["git"] = g
    return rep
