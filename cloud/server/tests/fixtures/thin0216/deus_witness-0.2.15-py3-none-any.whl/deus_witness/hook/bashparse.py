"""Witness class `command`: what a shell command line (Claude Code `Bash` tool) is about to do. Pure functions, no I/O except realpath.

classify(cmd, cwd, home) -> Command(danger=[...], writes=[...], opaque=bool)
  danger  "category:detail" strings, category one of DANGER_CATEGORIES; the detail is the target (path, remote, SQL verb ...)
  writes  absolute, normalised paths the line writes through redirections, tee, cp/mv/install, sed -i, dd of=, touch, mkdir
  net     hosts the line talks to over the network (curl/wget/http URLs, ssh/scp/rsync/sftp/nc/telnet targets, git clone/fetch/pull URLs)
  opaque  the line could not be read reliably (unbalanced quotes, eval, `$(...)` around a command name, too deep nesting)
  heads   command identifiers of every simple command (PROPOSAL-06 class `command`, action.recipient): the program's base name, plus the
          sub-command for the tools in SUBCOMMAND_TOOLS ("git status", "npm test"); also for $(...), backticks, `sh -c`, code heredocs.
          0.2.9: an identifier names exactly what runs, so that a read-only entry of the owner's list cannot be used to run something else:
          a program called by path keeps the path ("./ls"), and a form that runs other code or writes gets a variant suffix
          "<id> [<why>]" ("ls [env LD_PRELOAD]", "grep [via xargs]", "git status [-c]", "rg [--pre]", "git branch [write]"), see _variants()
0.2.11 (review 6): every redirection operator of bash and zsh is cut out of shlex's punctuation runs and named explicitly (_relex,
_redirects: `>|` writes its word, it is not a file called "|"); a redirection without a word or an operator we do not know is opaque.
A path the hook cannot know -- an expansion other than $HOME / $PWD, ~user, a substitution, a glob or brace in a write target -- is
opaque (asked as dangerous); `${...}` stays one word, so `cat ${HOME}/.ssh/id_rsa` is still a read of a secret. Substitutions are
classified at any depth (_substitute) within one budget per line (MAX_NESTED). Interpreters given code on the line are "<id> [eval]".

This is a TRIPWIRE, not a sandbox: an agent that writes a script and runs it, or uses an interpreter
(`python -c "import shutil; shutil.rmtree(...)"`), is caught only where a raw-text pattern below matches.
"""
from __future__ import annotations

import os
import re
import shlex
from dataclasses import dataclass, field

# tools whose first operand is a sub-command that changes what they do: the command identifier is "<tool> <sub-command>"
SUBCOMMAND_TOOLS = {"git", "npm", "pnpm", "yarn", "npx", "cargo", "go", "docker", "podman", "kubectl", "helm", "pip", "pip3", "uv", "poetry",
                    "brew", "apt", "apt-get", "systemctl", "launchctl", "make", "gh"}
SUBCOMMAND_RE = re.compile(r"[A-Za-z][A-Za-z0-9._:-]{0,63}")
MAX_HEADS = 32
DANGER_CATEGORIES = ("rm-rf", "sql-drop", "git-force-push", "git-destroy", "git-config", "pipe-to-shell", "secrets", "disk", "opaque")
DETAIL_MAX = 160
MAX_DEPTH = 4
MAX_NESTED = 128           # 0.2.11: substitutions, `sh -c`, eval, code heredocs of one line: more -> opaque (and no quadratic time)

SEPARATORS = {";", ";;", ";&", ";;&", "&&", "||", "|", "&", "|&", "\n", "(", ")", "{", "}"}
# 0.2.11 (R6-01): the shell's redirection operators, each named explicitly. shlex glues a run of punctuation into ONE token (">|", "&>>", ";>",
# "}>"); _relex cuts such a run into these operators, longest first, and _redirects judges each one. A run it cannot cut (none: every single
# character is an operator) or an operator without a word after it makes the line opaque: never "a write to a file named '|' in the project".
WRITE_OPS = {">", ">>", ">|", ">>|", "&>", "&>>", "&>|", "<>", ">&|"}       # the zsh forms (>>|, &>|, >&|) write too; bash rejects them
DUP_OPS = {">&", "<&"}                  # 2>&1, >&-, <&3 duplicate or close a descriptor; `>&file` / `>& file` writes the file (bash and zsh)
READ_OPS = {"<"}
WORD_OPS = {"<<", "<<<"}                # heredoc delimiter / here-string: the next word is data, not a path
REDIR_OPS = WRITE_OPS | DUP_OPS | READ_OPS | WORD_OPS
PUNCT = set(";&|<>(){}")
OPS = sorted(SEPARATORS - {"\n"} | REDIR_OPS, key=len, reverse=True)
REDIRECTS = WRITE_OPS
# 0.2.12: reserved words that start or continue a compound command: the simple command is the rest of the words (`if true; then cd /etc; fi`,
# `while x; do touch ~/f; done`, `! git push -f`, `coproc touch /etc/x`). Before, the hook took `then` / `do` / `!` for the program and did not
# see the command, its writes or a `cd` after them (found while fixing review 7).
KEYWORDS = {"if", "then", "else", "elif", "do", "while", "until", "!", "coproc"}
WRAPPERS = {"sudo", "doas", "nohup", "time", "command", "exec", "nice", "ionice", "stdbuf", "builtin", "chronic", "unbuffer",
            "setsid", "watch", "caffeinate", "proxychains", "proxychains4", "torsocks", "strace", "ltrace", "parallel", "taskset", "chrt"}
# CLIs whose job is talking to a remote service / publishing: the line is `opaque` (the owner decides), their sub-commands are not enumerated
CLOUD_CLIS = {"gh", "aws", "gcloud", "az", "gsutil", "rclone", "doctl", "heroku", "flyctl", "vercel", "netlify", "wrangler", "firebase", "terraform", "pulumi"}
PUBLISH = {("npm", "publish"), ("yarn", "publish"), ("pnpm", "publish"), ("cargo", "publish"), ("docker", "push"), ("podman", "push"),
           ("twine", "upload"), ("gem", "push"), ("helm", "push")}
SHELLS = {"sh", "bash", "zsh", "dash", "ksh", "fish", "busybox"}
INTERPRETERS = {"python", "python3", "node", "perl", "ruby", "php", "deno", "bun"}
FETCHERS = {"curl", "wget", "fetch", "http", "https", "iwr", "aria2c", "xh", "httpie"}
REMOTE_SHELLS = {"ssh", "scp", "sftp", "rsync", "nc", "ncat", "netcat", "telnet", "ftp", "mosh", "socat"}
CURL_VALUE_LONG = {"--output", "--data", "--data-raw", "--data-binary", "--data-urlencode", "--header", "--user", "--request", "--upload-file",
                   "--form", "--cookie", "--cookie-jar", "--config", "--max-time", "--write-out", "--proxy", "--user-agent", "--referer",
                   "--output-document", "--post-data", "--post-file", "--resolve", "--connect-to"}
URL_RE = re.compile(r"\b([a-zA-Z][a-zA-Z0-9+.-]{0,15})://(?:[^/@\s]*@)?(\[[0-9a-fA-F:.]+\]|[^/:?#\s\\\"'`]+)")
# 0.2.12 (R7-02): commands after which the hook no longer knows what the rest of the line does or where it runs: they run code from a
# string or a file (eval, source / ., trap's handler, a completion or mapfile callback), or change what a later word means (alias, hash -p,
# enable -f, shopt expand_aliases; zsh setopt / autoload / zmodload / emulate). The line is opaque, and a relative path after them is in an
# unknown directory (LOST_CWD), never "in the project".
EVALISH = {"eval", "source", ".", "alias", "unalias", "trap", "hash", "enable", "shopt", "setopt", "unsetopt", "fc", "bind", "complete",
           "compgen", "compdef", "function", "autoload", "zmodload", "emulate", "unfunction", "disable", "unhash", "functions"}
LOST_CWD = "/(unknown directory)"
DELETERS = {"rm", "unlink", "shred", "rmdir", "srm", "wipe"}
SAFE_SINKS = {"/dev/null", "/dev/stdout", "/dev/stderr", "/dev/tty"}
# 0.2.11 (R6-02): commands whose operands are files they read, copy or send: an operand the hook cannot resolve (`cat ${KEY}`) is opaque.
# The number is how many leading operands are not files (the pattern of grep / rg / sed / awk).
FILE_READERS = dict({n: 0 for n in ("cat", "head", "tail", "less", "more", "bat", "batcat", "nl", "tac", "rev", "base64", "base32", "xxd", "od",
                                    "hexdump", "strings", "wc", "file", "stat", "cp", "mv", "ln", "install", "tee", "source", ".", "scp", "rsync",
                                    "du", "ls", "diff", "cmp", "comm", "paste", "join", "cut", "sort", "uniq", "fold", "fmt", "pr", "split",
                                    "sha1sum", "sha256sum", "sha512sum", "md5sum", "shasum", "cksum", "gzip", "gunzip", "zcat", "bzip2", "xz",
                                    "zstd", "tar", "zip", "unzip", "7z", "gpg", "jq", "yq", "iconv", "dos2unix", "truncate", "touch", "mkdir",
                                    "rm", "rmdir", "unlink", "shred", "chmod", "chown", "dd", "open", "xdg-open", "pbcopy", "xclip")},
                    grep=1, egrep=1, fgrep=1, rg=1, ag=1, ack=1, sed=1, awk=1, gawk=1)

# 0.2.9: what makes a listed read-only command run something else (an entry of command.allow must not be a way to run other code).
# Environment assignments before a command (`LD_PRELOAD=./x.so ls`, `GIT_EXTERNAL_DIFF=./x git diff`, `PAGER=./x git log`): every variable
# except these display ones turns the identifier into "<id> [env VAR]".
SAFE_ENV = re.compile(r"(LANG|LANGUAGE|LC_[A-Z]+|TZ|NO_COLOR|FORCE_COLOR|CLICOLOR(_FORCE)?|TERM|COLUMNS|LINES|CI)")
SAFE_PAGER = {"GIT_PAGER", "PAGER"}                 # only with the value "cat" or empty
# wrappers that build a shell command line out of their arguments or of stdin: what runs is not what the list names
COMPOSING_WRAPPERS = {"xargs", "parallel", "watch"}
# git global options that do not change which code git runs; any other (-c, --config-env, --exec-path, --git-dir, --work-tree, -p ...) is a variant
GIT_SAFE_GLOBAL = {"-C", "--no-pager", "-P", "--no-optional-locks", "--literal-pathspecs", "--glob-pathspecs", "--noglob-pathspecs",
                   "--icase-pathspecs", "--no-replace-objects"}
# `git branch` options that only list (with them, operands are patterns or commits, nothing is created)
GIT_BRANCH_LIST = {"-l", "--list", "-a", "--all", "-r", "--remotes", "--contains", "--no-contains", "--merged", "--no-merged", "--points-at",
                   "--show-current", "-v", "-vv", "--verbose", "--sort", "--format", "--color", "--no-color", "--column", "--no-column",
                   "--abbrev", "--no-abbrev", "-i", "--ignore-case", "--omit-empty"}
# git configuration keys whose value is a program or code git runs later (`git config core.fsmonitor ./x` then `git status` runs ./x)
GIT_EXEC_KEY = re.compile(r"(core\.(fsmonitor|pager|editor|sshcommand|hookspath|gitproxy|askpass|alternaterefscommand)|diff\.external|"
                          r"(diff|merge|filter)\..+|alias\..+|credential\..*|sequence\.editor|gpg\..*program|pager\..+|"
                          r"include\.path|includeif\..+|uploadpack\..+|receivepack\..+|remote\..+\.(uploadpack|receivepack|proxy)|"
                          r"protocol\..+|url\..+|http\..*(proxy|curloptresolve)|instaweb\..+|web\.browser|browser\..+|man\..+)", re.I)
# files git reads its configuration and hooks from: a write there is a way to make a later `git status`/`git diff` run a program
GIT_EXEC_PATH = re.compile(r"(/\.git$|/\.git/(.+/)?(config|config\.worktree)$|/\.git/(.+/)?hooks(/|$)|/\.gitconfig$|/\.config/git/config$)")


# 0.2.10: per runner, options that change which code or configuration it loads, or what it deletes (see _variants)
RUNNER_OPTS = {
    "pytest": {"-p", "-c", "--config-file", "--rootdir", "--confcutdir", "-o", "--override-ini", "--basetemp", "--pyargs"},
    "py.test": {"-p", "-c", "--config-file", "--rootdir", "--confcutdir", "-o", "--override-ini", "--basetemp", "--pyargs"},
    "npm": {"--script-shell", "--node-options", "--userconfig", "--globalconfig"},
    "pnpm": {"--script-shell", "--node-options"},
    "yarn": {"--script-shell"},
    "make": {"-f", "--file", "--makefile", "-I", "--include-dir", "--eval"},
    "cargo": {"--config", "-Z"},
    "go": {"-exec", "-toolexec", "-overlay", "-modfile"},
    "npx": {"-p", "--package", "-c", "--call"},
    "mypy": {"--config-file", "--python-executable"},
    # 0.2.11 (R6-03): the runners a project allowance may now cover; options that load code, plugins or configuration from elsewhere
    "jest": {"-c", "--config", "--setupFiles", "--setupFilesAfterEnv", "--testRunner", "--transform", "--globalSetup", "--globalTeardown",
             "--testEnvironment", "--resolver", "--reporters", "--preset", "--rootDir", "--roots", "--moduleDirectories", "--modulePaths",
             "--watchPlugins", "--testSequencer", "--snapshotResolver", "--runner", "--projects"},
    "vitest": {"-c", "--config", "-r", "--root", "--dir", "--environment", "--globalSetup", "--setupFiles", "--reporter", "--pool", "--workspace"},
    "mocha": {"-r", "--require", "--config", "--package", "--file", "--ui", "-u", "--reporter", "-R", "--loader", "--node-option", "-n"},
    "eslint": {"-c", "--config", "--rulesdir", "--plugin", "--resolve-plugins-relative-to", "--parser", "-f", "--format"},
    "prettier": {"--plugin", "--config", "--plugin-search-dir"},
    "pylint": {"--load-plugins", "--init-hook", "--rcfile"},
    "tox": {"-c", "-x", "--override", "--conf"},
    "nox": {"-f", "--noxfile"},
    "ruff": {"--config"},
}
# 0.2.11 (R6-03): interpreters and runners given code on the command line (`node -e`, `tsx -e`, `python -c`, `ruby -e` ...): "<id> [eval]".
# Whatever an owner listed for `node build.js` / `python x.py` then does not cover code written into the line itself.
EVAL_OPTS = {"node": {"-e", "--eval", "-p", "--print", "-r", "--require", "--import", "--loader", "--experimental-loader"},
             "python": {"-c"}, "ruby": {"-e", "-r"}, "perl": {"-e", "-E", "-M", "-m"}, "php": {"-r", "-B", "-R", "-E", "-F"},
             "lua": {"-e", "-l"}, "Rscript": {"-e"}, "osascript": {"-e"}, "julia": {"-e", "-E"}, "deno": {"eval"}, "bun": {"-e", "--eval", "-p", "--print"}}
for _n in ("nodejs", "tsx", "ts-node", "ts-node-dev", "esno", "tsm", "swc-node", "babel-node", "vite-node", "nodemon"):
    EVAL_OPTS[_n] = EVAL_OPTS["node"]


def is_git_exec_path(p: str) -> bool:
    """0.2.9: git's configuration, hooks, or a `.git` file (`gitdir:` pointer). Writing it is judged as dangerous (category git-config)."""
    return bool(GIT_EXEC_PATH.search(p))

# Secrets: file names / directories whose CONTENT is a credential. Matched on path segments, not on substrings of words.
SECRET_NAME = re.compile(r"(^|/)(\.env(\.[\w.-]+)?|\.envrc|\.netrc|\.npmrc|\.pypirc|\.pgpass|\.git-credentials|\.?credentials(\.json)?|"
                         r"\.vault-token|\.terraformrc|id_(rsa|dsa|ecdsa|ed25519)(\.pub)?|[\w.-]+\.(pem|key|p12|pfx|jks|keystore|kdbx)|secrets?\.(ya?ml|json|toml|env))$", re.I)
SECRET_DIR = re.compile(r"(^|/)(\.ssh|\.aws|\.gnupg|\.kube|\.docker|\.config/(gcloud|gh|op)|\.azure|Library/Keychains)(/|$)", re.I)
SECRET_ENV = re.compile(r"\$\{?(\w*(SECRET|TOKEN|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY|ACCESS_KEY)\w*)\}?", re.I)
# Raw-text backstops (they also see inside quoted strings, heredocs and interpreter one-liners)
SQL_DROP = re.compile(r"\b(DROP\s+(TABLE|DATABASE|SCHEMA|INDEX|VIEW|USER|ROLE)|TRUNCATE\s+(TABLE\s+)?\w|DELETE\s+FROM\s+[\w.\"`]+\s*(;|$|\"|'))", re.I)
RAW_RM = re.compile(r"\b(shutil\.rmtree|fs\.rm(Sync)?\s*\([^)]{0,200}recursive|rimraf|os\.removedirs|FileUtils\.rm_r|rm\s+-[a-zA-Z]*[rR])", re.S)
RAW_PIPE_SHELL = re.compile(r"<\s*\(\s*(curl|wget)\b|\b(ba|z|da)?sh\s+-c\s+[\"']?\$\(\s*(curl|wget)\b|\beval\s+[\"']?\$\(\s*(curl|wget)\b", re.I)
PIPE_FROM = re.compile(r"\b(curl|wget|fetch|iwr)\b", re.I)
PIPE_INTO = re.compile(r"\s*(sudo\s+)?(\S*/)?((ba|z|da|k)?sh|python[0-9.]*|perl|ruby|node|php)\b", re.I)
MAX_CMD = 256 * 1024                       # a longer line is not parsed: `opaque` (the owner decides)
HEREDOC_READER = re.compile(r"(^|[;&|(]\s*)(sudo\s+)?(\S*/)?(sh|bash|zsh|dash|ksh|python[0-9.]*|node|perl|ruby|php|ssh|eval|source|\.(?=\s))(\b|(?<=\.))")


@dataclass
class Command:
    danger: list = field(default_factory=list)
    writes: list = field(default_factory=list)
    net: list = field(default_factory=list)
    heads: list = field(default_factory=list)
    opaque: bool = False
    outside: list = field(default_factory=list)   # 0.2.10: heads that ran outside the project or name a path outside it (no project allowance)

    def head(self, h: str) -> None:
        if not h or h in self.heads:
            return
        if len(self.heads) >= MAX_HEADS:            # never drop a command silently: a line too long to list is judged as dangerous
            self.opaque = True
            self.add("opaque", "more than %d commands" % MAX_HEADS)
            return
        self.heads.append(h)

    def add(self, cat: str, detail: str = "") -> None:
        d = "%s:%s" % (cat, " ".join(str(detail).split())[:DETAIL_MAX]) if detail else cat
        if d not in self.danger:
            self.danger.append(d)

    def out(self, h: str) -> None:
        if h and h not in self.outside:
            self.outside.append(h)

    def write(self, path: str) -> None:
        if path not in self.writes:
            self.writes.append(path)

    def host(self, h: str) -> None:
        h = h.lower().rstrip(".")
        if h not in self.net:
            self.net.append(h)


def _abspath(p: str, cwd: str, home: str) -> str:
    if p == "~" or p.startswith("~/"):
        p = home + p[1:]
    if not os.path.isabs(p):
        p = os.path.join(cwd, p)
    return os.path.realpath(p)      # symlinks are followed: a link inside the project that points outside is judged by its target


def is_secret_path(p: str) -> bool:
    return bool(SECRET_NAME.search(p) or SECRET_DIR.search(p))


KNOWN_VAR = re.compile(r"\$(?:\{(HOME|PWD)\}|(HOME|PWD)(?![A-Za-z0-9_]))")
# 0.2.11 (R6-02): a line that changes what $HOME / $PWD / ~ / a relative `cd` mean cannot have its paths resolved by the hook
REASSIGN = re.compile(r"(^|[\s;&|(])((export|local|declare|typeset|readonly)(\s+-\w+)*\s+)?(HOME|PWD|OLDPWD|CDPATH)\+?=|"
                      r"\b(read|unset|for|select|printf\s+-v|mapfile|readarray|getopts)\b[^;&|]*\b(HOME|PWD|OLDPWD|CDPATH)\b")


def _expand(w: str, cwd: str, home: str):
    """0.2.11 (R6-02): a word as the shell would see it as a path. $HOME/${HOME} and $PWD/${PWD} are what the hook knows; any other expansion
    ($VAR, ${...}, $(...), backticks, ~user, ~+, ~-) leaves the path unknown -> None (the caller fails closed)."""
    w = KNOWN_VAR.sub(lambda m: home if (m.group(1) or m.group(2)) == "HOME" else cwd, w)
    if re.search(r"[$`]", w) or re.match(r"~[^/]", w):
        return None
    return w


HD_WORD = re.compile(r"[A-Za-z_][A-Za-z0-9_.-]*")      # 0.2.12: a delimiter we accept; any other (empty, `$x`, `$'..'`, spaces ...) -> opaque
HD_META = set(" \t\n;&|<>()")


def _heredoc_word(cmd: str, k: int):
    """0.2.12 (R7-01): the delimiter after `<<` / `<<-` read as bash reads it: the WHOLE shell word up to an unquoted metacharacter, quotes
    removed (`E\\OF`, `E'O'F`, `"E"OF`, `EOF''` are all EOF, and quoted: the body is data). -> (delimiter, quoted, end) or None when the
    word is not one we can be sure of (no word, `$` or a backtick in it, a line continuation, an unclosed quote, a name outside HD_WORD)."""
    n = len(cmd)
    while k < n and cmd[k] in " \t":
        k += 1
    val, quoted, start = [], False, k
    while k < n and cmd[k] not in HD_META:
        ch = cmd[k]
        if ch == "\\":
            if k + 1 >= n or cmd[k + 1] == "\n":
                return None
            val.append(cmd[k + 1])
            quoted, k = True, k + 2
        elif ch == "'":
            j = cmd.find("'", k + 1)
            if j < 0:
                return None
            val.append(cmd[k + 1:j])
            quoted, k = True, j + 1
        elif ch == '"':
            j = k + 1
            while j < n and cmd[j] != '"':
                if cmd[j] in "$`" or cmd[j:j + 2] == "\\\n":
                    return None
                if cmd[j] == "\\" and j + 1 < n and cmd[j + 1] in '"\\':
                    j += 1
                val.append(cmd[j])
                j += 1
            if j >= n:
                return None
            quoted, k = True, j + 1
        elif ch in "$`":
            return None
        else:
            val.append(ch)
            k += 1
    d = "".join(val)
    if k == start or not HD_WORD.fullmatch(d):
        return None
    return d, quoted, k


def _normalize(cmd: str):
    """Quote-aware pass: an unquoted newline becomes ";", unquoted comments are dropped, heredoc bodies are cut out.
    -> (one-line command, [(line that opened the heredoc, body, delimiter quoted?)], balanced quotes?, why unsure or None)
    0.2.12 (R7-01): heredocs are found as bash finds them. The delimiter is the whole word with quotes removed (_heredoc_word); the body ends
    at the first line EQUAL to it (`<<-`: after leading tabs), not at a stripped line. `<<` inside `$((..))`, `((..))`, `$[..]` or `${..}` is
    not a heredoc (a shift, or text). Fail closed (-> the line is opaque) on anything we might read differently from bash: a delimiter we do
    not accept, a body that never ends, a line continuation in a body with an unquoted delimiter (bash joins it before comparing), a body
    that would start inside another construct than the one that opened it, an arithmetic `((` that turns out not to be one, a body inside
    backticks with a backtick in it (bash finds the end of `..` before it reads a heredoc in it)."""
    out, docs, q, i, n = [], [], None, 0, len(cmd)
    line_start = 0
    pending = []                           # heredocs opened on the current line: (delimiter, quoted, strip tabs, contexts when opened)
    # unquoted contexts, innermost last: [kind, saw "<<", plain "(" inside]; R = the line, C = $( <( >(, A + a = $(( / ((, B = ${ {, S = $[ [,
    # K = `...`
    stack = [["R", False, 0]]
    while i < n:
        ch = cmd[i]
        if q is None:
            top = stack[-1]
            kind, k = top[0], 0
            if ch == "\\" and i + 1 < n:
                out.append(cmd[i:i + 2]) if cmd[i + 1] != "\n" else None
                i += 2
                continue
            if ch in "'\"":
                q = ch
            elif ch == "#" and (i == 0 or cmd[i - 1] in " \t\n;&|("):
                while i < n and cmd[i] != "\n":
                    i += 1
                continue
            elif cmd.startswith("<<<", i):
                out.append("<<<")                  # here-string: the word is data (judged in classify), not a heredoc delimiter
                i += 3
                continue
            elif cmd.startswith("<<", i):
                if kind in ("A", "a", "B", "S"):
                    top[1] = True                  # a shift (or text in ${..}), as long as this really is arithmetic (checked at its end)
                    out.append("<<")
                    i += 2
                    continue
                strip = cmd.startswith("<<-", i)
                w = _heredoc_word(cmd, i + 2 + strip)
                if w is None:
                    return "".join(out), docs, q is None, "heredoc delimiter not understood"
                pending.append((w[0], w[1], strip, [(e[0], e[2]) for e in stack]))
                out.append(" << __HEREDOC__ ")
                i = w[2]
                continue
            elif kind not in ("B", "S") and (cmd.startswith("$((", i) or cmd.startswith("((", i)):
                stack += [["A", False, 0], ["a", False, 0]]
                k = 3 if ch == "$" else 2
            elif cmd.startswith(("$(", "<(", ">("), i):
                stack.append(["C", False, 0])
                k = 2
            elif cmd.startswith("${", i) or (ch == "{" and kind == "B"):
                stack.append(["B", False, 0])
                k = 2 if ch == "$" else 1
            elif cmd.startswith("$[", i) or (ch == "[" and kind == "S"):
                stack.append(["S", False, 0])
                k = 2 if ch == "$" else 1
            elif ch == "`":
                if kind == "K":
                    stack.pop()                    # a backtick substitution: a heredoc may live inside it, one opened outside may not start in it
                else:
                    stack.append(["K", False, 0])
                k = 1
            elif (ch == "}" and kind == "B") or (ch == "]" and kind == "S"):
                stack.pop()
                k = 1
            elif ch == "(" and kind not in ("B", "S"):
                top[2] += 1
                k = 1
            elif ch == ")" and kind not in ("B", "S"):
                k = 1
                if top[2]:
                    top[2] -= 1
                elif kind == "a":
                    stack.pop()
                    if cmd.startswith(")", i + 1):
                        stack.pop()                # `))`: the arithmetic really ends here
                        k = 2
                    elif top[1]:
                        return "".join(out), docs, q is None, "<< in an arithmetic that is not one"
                    else:
                        stack[-1][0] = "C"         # `$((1) + (2))`: bash reads a command substitution of a subshell after all
                elif kind != "R":
                    stack.pop()
            if k:
                out.append(cmd[i:i + k])
                i += k
                continue
            elif ch == "\n":
                out.append(" ; ")
                head = cmd[line_start:i]           # the whole line that opened the heredoc(s): `cat <<EOF | sh` reads it as code
                i += 1
                for delim, quoted, strip, ctx in pending:
                    if ctx != [(e[0], e[2]) for e in stack]:
                        return "".join(out), docs, q is None, "heredoc body inside another construct"
                    body, closed = [], False
                    while i < n:
                        j = cmd.find("\n", i)
                        j = n if j < 0 else j
                        ln = cmd[i:j]
                        i = j + 1
                        if (ln.lstrip("\t") if strip else ln) == delim:
                            closed = True
                            break
                        if "`" in ln and any(kd == "K" for kd, _ in ctx):
                            return "".join(out), docs, q is None, "heredoc inside backticks"   # bash ends `..` first, at any backtick
                        if not quoted and (len(ln) - len(ln.rstrip("\\"))) % 2 == 1:
                            return "".join(out), docs, q is None, "line continuation in a heredoc body"
                        body.append(ln)
                    if not closed and body:
                        return "".join(out), docs, q is None, "heredoc %s never ends" % delim
                    docs.append((head, "\n".join(body), quoted))
                pending = []
                line_start = i
                continue
        elif ch == q:
            q = None
        elif q == '"' and ch == "\\" and i + 1 < n:
            out.append(cmd[i:i + 2])
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out), docs, q is None, None


def _tokens(cmd: str):
    lx = shlex.shlex(cmd, posix=True, punctuation_chars=";&|<>(){}")
    lx.whitespace_split = True
    lx.commenters = ""
    return _relex(list(lx))


def _relex(toks):
    """0.2.11 (R6-01): shlex returns a run of punctuation as one token (">|", "2>&1" -> ">&", ";>", "}>"); cut it into shell operators,
    longest first (">|" is ">|", not ">" followed by a word "|")."""
    out = []
    for t in toks:
        if t and set(t) <= PUNCT:
            k = 0
            while k < len(t):
                op = next(o for o in OPS if t.startswith(o, k))
                out.append(op)
                k += len(op)
        else:
            out.append(t)
    return out


FD_VAR = re.compile(r"\{[A-Za-z_][A-Za-z0-9_]*\}(?=[<>])")


def _close(s: str, k: int):
    """Index of the ")" that closes the "(" at s[k], quote-aware; None when there is none."""
    depth, q, i = 0, None, k
    while i < len(s):
        ch = s[i]
        if q == "'":
            q = None if ch == "'" else q
        elif ch == "\\":
            i += 1
        elif q == '"':
            q = None if ch == '"' else q
        elif ch in "'\"":
            q = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return None


def _substitute(line, c, cwd, home, depth, project, data=False):
    """0.2.11: quote-aware pass over the one-line command. Every command substitution `$(...)`, backtick and process substitution `<(...)` /
    `>(...)`, at any nesting depth, is classified as a command line of its own and replaced by one word: "$__SUB__" (a value the hook cannot
    know: a path made of it is unknown) or "/dev/fd/63" (process substitution); `$((...))` -> "$__ARITH__" (substitutions inside it are
    classified); `${...}` stays one word (the tokenizer no longer cuts `${HOME}/.ssh/id_rsa` at the braces, R6-02); `{fd}` before a
    redirection is dropped (`exec {fd}>f` writes f). -> the new line, or None when it cannot be read (unclosed, nested `${..$(..)}`, a "("
    glued to a word: extglob `@(..)` / zsh glob qualifiers `*(e:..:)` run code or build names we cannot see, unbalanced parentheses).
    data=True: the body of a heredoc whose delimiter is not quoted -- quotes are text and only `$(...)`, `$((...))` and backticks run."""
    out, i, n, q, parens = [], 0, len(line), None, 0
    while i < n:
        ch = line[i]
        if q == "'":
            out.append(ch)
            q = None if ch == "'" else q
            i += 1
            continue
        if ch == "\\" and i + 1 < n:
            out.append(line[i:i + 2])
            i += 2
            continue
        if data and ch not in "$`":
            out.append(ch)
            i += 1
            continue
        if ch == "'" and q is None or ch == '"':
            q = ch if q is None else None
            out.append(ch)
            i += 1
            continue
        if ch == "`":
            j = i + 1
            while j < n and line[j] != "`":
                j += 2 if line[j] == "\\" else 1
            if j >= n:
                return None
            _merge(c, classify(line[i + 1:j].replace("\\`", "`"), cwd, home, depth + 1, project, _budget=c.budget))
            if c.budget[0] < 0:
                return None
            out.append("$__SUB__")
            i = j + 1
            continue
        if ch == "$" and line.startswith("$((", i):
            j = _close(line, i + 1)
            c.budget[0] -= 1
            if j is None or c.budget[0] < 0 or _substitute(line[i + 3:j - 1], c, cwd, home, depth + 1, project) is None:
                return None
            out.append("$__ARITH__")
            i = j + 1
            continue
        if (ch == "$" or (ch in "<>" and q is None)) and line.startswith("(", i + 1):
            j = _close(line, i + 1)
            if j is None:
                return None
            _merge(c, classify(line[i + 2:j], cwd, home, depth + 1, project, _budget=c.budget))
            if c.budget[0] < 0:
                return None
            out.append("$__SUB__" if ch == "$" else " /dev/fd/63")
            i = j + 1
            continue
        if ch == "$" and line.startswith("${", i) and not data:
            j = line.find("}", i + 2)
            if j < 0 or not re.fullmatch(r"[^\"'`{}\\$()\s]*", line[i + 2:j]):
                return None
            out.append(line[i:j + 1] if q == '"' else '"%s"' % line[i:j + 1])
            i = j + 1
            continue
        if q is None and not data:
            m = FD_VAR.match(line, i)
            if m and (i == 0 or line[i - 1] in " \t;&|("):
                out.append(" ")
                i = m.end()
                continue
            if ch == "(":
                if i > 0 and line[i - 1] not in " \t;&|(=" and not line.startswith("()", i):
                    return None
                parens += 1
            elif ch == ")":
                parens -= 1
                if parens < 0:
                    return None
        out.append(ch)
        i += 1
    return "".join(out) if parens == 0 else None


def _split_ctx(tokens):
    """0.2.12: -> [(argv, separator before, separator after, subshell depth)] for every simple command (`(` .. `)` is a subshell)."""
    out, cur, before, depth = [], [], None, 0
    for p in tokens:
        if p in SEPARATORS:
            if cur:
                out.append((cur, before, p, depth))
                cur = []
            before = p
            depth += (p == "(") - (p == ")")
            depth = max(depth, 0)
        elif p != "":
            cur.append(p)
    if cur:
        out.append((cur, before, None, depth))
    return out


def _split(tokens):
    """-> list of simple commands, each a list of tokens."""
    cmds, cur = [], []
    for p in tokens:
        if p in SEPARATORS:
            if cur:
                cmds.append(cur)
            cur = []
        elif p != "":
            cur.append(p)
    if cur:
        cmds.append(cur)
    return cmds


def _strip_prefix(argv):
    """Drop VAR=value assignments and wrappers (sudo, env, timeout 5, nice -n 5, xargs ...). -> (argv, via_xargs)."""
    xargs = False
    i = 0
    while i < len(argv):
        a = argv[i]
        base = os.path.basename(a)
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", a):
            i += 1
        elif a in KEYWORDS:
            i += 1                                   # 0.2.12: `then touch ~/.bashrc`, `do git push -f`, `! cd /etc`: the command is what follows
        elif base in WRAPPERS or base == "env":
            i += 1
            while i < len(argv) and (argv[i].startswith("-") or (base == "env" and "=" in argv[i])):
                i += 1 + (argv[i] in ("-u", "-n", "-c", "-C", "-p", "-g", "-U") and base != "env")
        elif base == "busybox" and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
            i += 1                                   # `busybox wget URL` is `wget URL`
        elif base == "flock":
            i += 1
            while i < len(argv) and argv[i].startswith("-"):
                i += 1
            i += 1                                   # the lock file
        elif base == "timeout":
            i += 1
            while i < len(argv) and argv[i].startswith("-"):
                i += 1
            i += 1                                   # the duration
        elif base == "xargs":
            xargs = True
            i += 1
            while i < len(argv) and argv[i].startswith("-"):
                i += 1 + (argv[i] in ("-I", "-n", "-P", "-d", "-E", "-L", "-s", "-a"))
        else:
            break
    return argv[i:], xargs


def _flags(args):
    """Short flags joined ("-rf" -> {"r","f"}) and long flags ("--force"). Stops at "--"."""
    short, long_ = set(), set()
    for a in args:
        if a == "--":
            break
        if a.startswith("--"):
            long_.add(a.split("=", 1)[0])
        elif a.startswith("-") and len(a) > 1:
            short |= set(a[1:])
    return short, long_


def _operands(args):
    out, end = [], False
    for a in args:
        if end or not a.startswith("-") or a == "-":
            out.append(a)
        elif a == "--":
            end = True
    return out


def _npx_local(pkg: str, here: str) -> bool:
    """0.2.10: `npx jest` runs the project's own node_modules/.bin/jest when there is one (searched upwards, as npx does), else it downloads."""
    d = here
    while True:
        if os.path.exists(os.path.join(d, "node_modules", ".bin", pkg)):
            return True
        up = os.path.dirname(d)
        if up == d:
            return False
        d = up


def _in_project(p: str, project: str) -> bool:
    return p == project or p.startswith(project.rstrip("/") + "/")


PATHLIKE = re.compile(r"(/|~|\.\.?(/|$))")


def _outside(args, here, home, project) -> bool:
    """0.2.10: does this simple command run outside the project, or name a path outside it (`pytest /tmp/t.py`, `make -C ..`,
    `--rootdir=/x`)? A path from an expansion cannot be judged: outside. Used only to refuse a project allowance, never to allow."""
    if not _in_project(here, project):
        return True
    for a in args:
        v = a.split("=", 1)[1] if a.startswith("-") and "=" in a else a
        if not v or not (PATHLIKE.match(v) or "/" in v):
            continue
        e = _expand(v, here, home)
        if e is None or not _in_project(_abspath(e, here, home), project):
            return True
    return False


def classify(cmd: str, cwd: str, home: str | None = None, _depth: int = 0, project: str | None = None, _budget=None) -> Command:
    """project (0.2.10): the realpath of the project root; given, `outside` lists the heads that ran outside it (see _outside).
    _budget (0.2.11): command lines left to classify for the whole line ([n], shared by every nested call, MAX_NESTED)."""
    home = home or os.path.expanduser("~")
    c = Command()
    c.budget = _budget if _budget is not None else [MAX_NESTED]
    c.budget[0] -= 1
    if c.budget[0] < 0:
        c.opaque = True
        c.add("opaque", "more than %d nested command lines" % MAX_NESTED)
        return c
    if not isinstance(cmd, str):
        c.opaque = True
        c.add("opaque", "not a string")
        return c
    if len(cmd) > MAX_CMD:
        c.opaque = True
        c.add("opaque", "command of %d characters" % len(cmd))
        return c
    _raw_scan(cmd, c)
    if _depth > MAX_DEPTH:
        c.opaque = True
        c.add("opaque", "nesting deeper than %d" % MAX_DEPTH)
        return c
    line, docs, balanced, unsure = _normalize(cmd)
    if unsure:
        c.opaque = True                                    # 0.2.12 (R7-01): we might not cut the line where bash does
        c.add("opaque", unsure)
        return c
    if re.search(r"(?<!\$)\{[^{}\s]*(,|\.\.)[^{}\s]*\}", re.sub(r"'[^']*'|\"(?:[^\"\\]|\\.)*\"", "", line)):
        c.opaque = True                                    # `{rm,-rf,/x}`, `> .git/hook{s..s}/x`: the shell builds the words after we parsed them
        c.add("opaque", "brace expansion")
    if REASSIGN.search(line):
        c.opaque = True                                    # 0.2.11: `HOME=/etc; echo x > ~/f`: the hook's $HOME / ~ / cwd no longer hold
        c.add("opaque", "HOME / PWD / CDPATH changed in the line")
    raw_rm = RAW_RM.search(line)                           # heredoc DATA is not code; code heredocs are classified below
    for head, body, quoted in docs:
        if HEREDOC_READER.search(head.strip()):            # `bash <<EOF`, `python - <<EOF`, `ssh host <<EOF`: the body is code
            _merge(c, classify(body, cwd, home, _depth + 1, project, _budget=c.budget))
        elif not quoted and _substitute(body, c, cwd, home, _depth, project, data=True) is None:
            c.opaque = True                                # 0.2.11: `cat <<EOF` (delimiter not quoted) runs the $(...) / `...` of its body
            c.add("opaque", "heredoc body with an unreadable substitution")
    # 0.2.11: command, process and arithmetic substitutions at any depth are classified as command lines of their own and replaced by one word
    sub = _substitute(line, c, cwd, home, _depth, project)
    if sub is None:
        c.opaque = True
        c.add("opaque", "unparsable substitution or parenthesis")
        return c
    line = sub
    try:
        if not balanced:
            raise ValueError("No closing quotation")
        toks = _tokens(line)
    except ValueError as e:                     # unbalanced quotes: cannot know where words end
        c.opaque = True
        c.add("opaque", "unparsable (%s)" % e)
        return c
    here = cwd
    if _defines_function(toks):
        c.opaque = True                                    # 0.2.12 (R7-02): any later word may run the function: its effect is unknown
        c.add("opaque", "function defined in the line")
        here = LOST_CWD
    # 0.2.12: where each simple command runs. A `cd` changes the directory for sure only when it runs in this shell (not in a pipeline, in the
    # background or in a `( )` subshell, which ends at its `)`), unconditionally (not after && / || / then / do ...) and into a directory that
    # exists (bash stays where it was when `cd` fails). Otherwise the commands after it in the same && chain run there, and the commands after
    # the chain run in one of two directories: unless both are the same, the directory is unknown (LOST_CWD) -- never "the project" by guess.
    depth_here, last_depth, fallback = {0: here}, 0, None
    for argv, before, after, depth in _split_ctx(toks):
        if depth != last_depth or (fallback is not None and before != "&&"):
            if fallback is not None and fallback != here:
                here = LOST_CWD
            fallback = None
            depth_here[last_depth] = here
            if depth > last_depth:
                for d in range(last_depth + 1, depth + 1):
                    depth_here[d] = depth_here[d - 1]
            here, last_depth = depth_here[depth], depth
        if len(argv) == 1 and os.path.basename(argv[0]) == "env":
            c.add("secrets", "whole environment")
        if "<<<" in argv:                                      # here-string into a shell / interpreter is code
            k = argv.index("<<<")
            pre, _ = _strip_prefix(argv[:k])
            if pre and (os.path.basename(pre[0]) in SHELLS | INTERPRETERS | {"eval", "source", "."}) and k + 1 < len(argv):
                _merge(c, classify(argv[k + 1], cwd, home, _depth + 1, project, _budget=c.budget))
        argv, redirect_writes = _redirects(argv, here, home, c)
        for p in redirect_writes:
            c.write(p)
        full = argv
        argv, via_xargs = _strip_prefix(argv)
        if not argv:
            continue
        name = os.path.basename(argv[0])
        args = argv[1:]
        if len(argv) == 1 and argv[0] in ("fi", "done", "esac"):
            continue                                       # 0.2.12: the end of a compound command runs nothing (its redirections are judged above)
        if not re.search(r"[$`]", argv[0]):
            prefix = full[:len(full) - len(argv)]
            elevated = any(os.path.basename(x) in ("sudo", "doas") for x in prefix)
            if any(os.path.basename(x) == "env" for x in prefix) and any(x in ("-S", "--split-string") or x.startswith(("-S", "--split-string="))
                                                                        for x in prefix):
                c.opaque = True                                # `env -S "..."` splits a string into a command line we did not parse
                c.add("opaque", "env -S")
            ident = command_id(argv[0] if "/" in argv[0] else name, args)       # `./ls` / `/tmp/x/cat` is not the `ls` / `cat` of the list
            tags = _variants(name, args, prefix)
            if name == "npx" and ident != "npx" and not _npx_local(ident.split(" ", 1)[1], here):
                tags.append("fetch")                          # 0.2.10: not installed in the project: npx would download it from the registry
            hid = ("sudo " if elevated else "") + ident + (" [%s]" % ", ".join(tags) if tags else "")
            c.head(hid)   # `sudo ls` is not `ls` for the owner's list
            if project is not None and _outside(args, here, home, project):
                c.out(hid)
        if name in EVALISH or (name in ("mapfile", "readarray") and any(a.startswith("-") and "C" in a for a in args)):
            c.opaque = True                                # 0.2.12 (R7-02): what the rest of the line means (its directory, its commands)
            c.add("opaque", "%s: the rest of the line cannot be judged" % name)     # is not known after eval / source / alias / trap ...
            here = LOST_CWD
        if name in ("cd", "pushd", "popd") and here == LOST_CWD:
            continue                                       # `cd` itself may be a function or alias by now: the directory stays unknown
        if name in ("cd", "pushd", "popd"):
            ops = _operands(args)
            new = None
            if name == "popd" or ops[:1] == ["-"] or any(re.fullmatch(r"[+-]\d+", o) for o in ops):
                c.opaque = True                                # 0.2.11: the directory stack / OLDPWD: the hook does not know where that is
                c.add("opaque", name + " " + " ".join(ops))
            elif ops and _expand(ops[0], here, home) is not None and not re.search(r"[*?[]", ops[0]):
                new = _abspath(_expand(ops[0], here, home), here, home)
            elif ops:
                c.opaque = True
                c.add("opaque", "cd " + ops[0])
            elif name == "cd":
                new = home
            else:
                c.opaque = True
                c.add("opaque", "pushd")
            if new is not None and new != here:
                kw = any(x in KEYWORDS for x in full[:len(full) - len(argv)])
                if before in ("|", "|&") or after in ("|", "|&", "&"):
                    here = LOST_CWD                            # zsh runs the last part of a pipeline in this shell, bash does not
                elif os.path.isdir(new) and before not in ("&&", "||") and not kw and not any(new == w or _in_project(new, w) for w in c.writes) \
                        and not any(d.startswith("rm-rf") for d in c.danger):
                    here = new                                 # runs, and succeeds: it exists, and nothing before wrote, moved or deleted it
                else:
                    fallback = here if fallback is None else fallback
                    here = new                                 # true for the rest of this && chain only
            continue
        if re.search(r"[$`]", argv[0]):
            c.opaque = True
            c.add("opaque", "command name from expansion: " + argv[0])
            continue
        _one(name, args, here, home, c, via_xargs, _depth, project)
    if raw_rm and not any(d.startswith("rm-rf") for d in c.danger):
        c.add("rm-rf", raw_rm.group(0))           # inside a quoted string / interpreter one-liner / heredoc data
    lost = [w for w in c.writes if _in_project(w, LOST_CWD)]
    if lost:                                      # 0.2.12 (R7-02): a relative write after the directory became unknown is not "in the project"
        c.writes = [w for w in c.writes if w not in lost]
        c.opaque = True
        c.add("opaque", "write to a relative path in an unknown directory")
    return c


def _defines_function(toks) -> bool:
    """0.2.12 (R7-02): `f(){ ...; }`, `f () ...`, `function f`, zsh's anonymous `() { ...; }`."""
    for k, t in enumerate(toks):
        if t == "(" and toks[k + 1:k + 2] == [")"] and (k == 0 or toks[k - 1] not in SEPARATORS or toks[k + 2:k + 3] == ["{"]):
            return True
        if t == "function" and (k == 0 or toks[k - 1] in SEPARATORS):
            return True
    return False


PY_MODULE = re.compile(r"python[0-9.]*")
MODULE_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*")


def command_id(name: str, args) -> str:
    """PROPOSAL-06: the identifier the owner's `command.allow` list is matched against (byte-exact or a trailing-* prefix).
    0.2.10: `python -m pytest` is "python -m pytest" (it runs that module, not code given on the line), not "python"."""
    if PY_MODULE.fullmatch(name) and args[:1] == ["-m"] and len(args) > 1 and MODULE_RE.fullmatch(args[1]):
        return "%s -m %s" % (name, args[1])
    if name not in SUBCOMMAND_TOOLS:
        return name
    i = 0
    while i < len(args) and args[i].startswith("-"):           # global options: git -C dir, -c k=v, --no-pager; npm --prefix x
        i += 1 + (args[i] in ("-C", "-c", "--git-dir", "--work-tree", "--prefix", "--manifest-path", "-f", "--file", "-n", "--namespace", "--context"))
    if i < len(args) and SUBCOMMAND_RE.fullmatch(args[i]):
        return name + " " + args[i]
    return name


def _eval_form(name: str, args) -> bool:
    """0.2.11: code given on the command line of an interpreter (EVAL_OPTS), before its script operand."""
    opts = EVAL_OPTS.get("python" if PY_MODULE.fullmatch(name) else name)
    if not opts:
        return False
    if name == "deno":
        return args[:1] == ["eval"]
    for a in args:
        if not a.startswith("-") or a == "--":
            return False                                     # the script: what follows are its own arguments
        o = a.split("=", 1)[0]
        if o in opts or (not a.startswith("--") and any(len(x) == 2 and x[1] in a[1:] for x in opts)):
            return True
    return False


def _variants(name: str, args, prefix) -> list:
    """0.2.9: why this simple command is not the plain read-only command its name says -> ["env LD_PRELOAD", "via xargs", "-c", ...].
    A non-empty list makes the identifier "<id> [<tags>]", which no plain entry of the owner's list matches (the owner is asked)."""
    tags = []
    env = sorted({a.split("=", 1)[0] for a in prefix if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", a)
                  and not SAFE_ENV.fullmatch(a.split("=", 1)[0])
                  and not (a.split("=", 1)[0] in SAFE_PAGER and a.split("=", 1)[1] in ("", "cat"))})
    if env:
        tags.append("env " + ",".join(env)[:64])
    for w in sorted({os.path.basename(a) for a in prefix} & COMPOSING_WRAPPERS):
        tags.append("via " + w)
    short, long_ = _flags(args)
    if name == "git":
        i = 0
        while i < len(args) and args[i].startswith("-"):
            o = args[i].split("=", 1)[0]
            if o not in GIT_SAFE_GLOBAL:
                tags.append(o)
            i += 1 + (args[i] in ("-C", "-c", "--git-dir", "--work-tree", "--namespace", "--config-env", "--exec-path") and "=" not in args[i])
        sub, rest = (args[i], args[i + 1:]) if i < len(args) else ("", [])
        if any(a == "--output" or a.startswith("--output=") or a == "--output-directory" or a.startswith("--output-directory=") for a in rest):
            tags.append("--output")
        for o in sorted({a.split("=", 1)[0] for a in rest} & {"--upload-pack", "--receive-pack", "--exec", "--extcmd", "--tool"}):
            tags.append(o)                                   # 0.2.11: `git fetch --upload-pack=<cmd>` / `rebase --exec` run that command
        if sub == "branch":
            rs, rl = _flags(rest)
            modify = (rs & set("dDmMcCfu") or rl & {"--delete", "--move", "--copy", "--force", "--set-upstream-to", "--unset-upstream",
                                                     "--edit-description", "--track", "--no-track", "--create-reflog", "--recurse-submodules"})
            listing = {a.split("=", 1)[0] for a in rest if a.startswith("-")} & GIT_BRANCH_LIST
            if modify or (_operands(rest) and not listing):
                tags.append("write")
    elif name == "rg" and any(a.split("=", 1)[0] in ("--pre", "--hostname-bin") for a in args):
        tags.append("--pre" if any(a.split("=", 1)[0] == "--pre" for a in args) else "--hostname-bin")     # ripgrep runs that program
    elif name == "date" and ("s" in short or "--set" in long_):
        tags.append("--set")                                 # sets the system clock
    elif name == "file" and ("C" in short or "--compile" in long_):
        tags.append("--compile")                             # writes a .mgc file
    elif name == "sort" and "--compress-program" in long_:
        tags.append("--compress-program")                    # sort runs that program
    elif _install_sub(name, args) is not None:
        tags += _install_tags(name, _install_sub(name, args))
    elif _eval_form(name, args):
        tags.append("eval")
    elif PY_MODULE.fullmatch(name) and args[:1] == ["-m"] and len(args) > 1 and args[1] in RUNNER_OPTS:
        tags += _variants(args[1], args[2:], [])                 # 0.2.10: `python -m pytest -p x` is `python -m pytest [-p]`
    elif name in RUNNER_OPTS:
        # 0.2.10: options of test runners / build tools that load code or configuration from elsewhere, or delete a directory they name:
        # with them it is not the plain `pytest` / `make` / `cargo test` an owner allowed for the project ("<id> [<option>]", asked)
        opts = RUNNER_OPTS[name]
        for k, a in enumerate(args):
            if a == "--":
                break
            o = a.split("=", 1)[0]
            if o in opts:
                hit = o
            elif re.fullmatch(r"-[A-Za-z]+.*", a) and not a.startswith("--"):       # a short cluster `-vp x`, `-pplugin`, `-sfOther.mk`
                hit = next((x for x in sorted(opts) if len(x) == 2 and x[1] in re.match(r"-([A-Za-z]+)", a).group(1)), None)
            else:
                hit = None
            if hit == "-p" and (a[2:] if a.startswith("-p") and len(a) > 2 else (args[k + 1] if k + 1 < len(args) else "")).startswith("no:"):
                hit = None                                   # `-p no:cacheprovider` only switches a plugin off
            if hit and hit not in tags:
                tags.append(hit)
        if name == "make" and any(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*=.*", a) for a in _operands(args)):
            tags.append("vars")                              # `make SHELL=./x CC=./y`: overrides decide what make runs
        if name == "npx":                                    # 0.2.11: `npx jest --config x` is judged by jest's own options too
            k = next((k for k, x in enumerate(args) if not x.startswith("-")), None)
            if k is not None and args[k] in RUNNER_OPTS and args[k] != "npx":
                tags += [t for t in _variants(args[k], args[k + 1:], []) if t not in tags]
    return tags


# 0.2.10: installers. `npm install` / `npm ci` / `pip install -e .` / `pip install -r requirements.txt` install what the PROJECT declares
# (package.json + lockfile, its own requirements); naming a package (`npm install left-pad`, `pip install requests`, `pip install -e git+https://...`)
# or another index (`--registry`, `--index-url`, `--find-links` ...) installs code the project does not declare: "<id> [packages]" / "<id> [--index-url]".
NPM_INSTALL = {"install", "i", "ci", "add", "isntall", "in", "ins", "inst", "insta", "instal", "isnt", "isnta", "isntal"}
PIP_VALUE = {"-r", "--requirement", "-c", "--constraint", "-e", "--editable", "-t", "--target", "--prefix", "--root", "--src", "-b", "--build",
             "--python-version", "--platform", "--implementation", "--abi", "--progress-bar", "--log", "--cache-dir", "--report", "--upgrade-strategy",
             "--config-settings", "-C", "--global-option", "--install-option", "--only-binary", "--no-binary"}
PIP_REMOTE = {"-i", "--index-url", "--extra-index-url", "-f", "--find-links", "--trusted-host", "--proxy", "--cert", "--client-cert"}
NPM_REMOTE = {"--registry", "--userconfig", "--globalconfig"}
PATHY = re.compile(r"(\.|\.\.|[.~]?/.*|[^:]*\.(txt|in|cfg|toml))$")


def _install_sub(name, args):
    """-> the arguments after the install sub-command of npm / pnpm / yarn / pip / pip3 / python -m pip, or None."""
    if PY_MODULE.fullmatch(name) and args[:2] == ["-m", "pip"]:
        name, args = "pip", args[2:]
    if name in ("pip", "pip3"):
        ops = [i for i, a in enumerate(args) if not a.startswith("-")]
        return args[ops[0] + 1:] if ops and args[ops[0]] == "install" else None
    if name in ("npm", "pnpm", "yarn"):
        ops = [i for i, a in enumerate(args) if not a.startswith("-")]
        return args[ops[0] + 1:] if ops and args[ops[0]] in NPM_INSTALL else None
    return None


def _install_tags(name, rest):
    tags = []
    pip = name in ("pip", "pip3") or PY_MODULE.fullmatch(name)
    remote = PIP_REMOTE if pip else NPM_REMOTE
    for o in sorted({a.split("=", 1)[0] for a in rest if a.startswith("-")} & remote):
        tags.append(o)
    pkgs, k = False, 0
    while k < len(rest):
        a = rest[k]
        if a == "--":
            pkgs = pkgs or k + 1 < len(rest)
            break
        if pip and a.split("=", 1)[0] in PIP_VALUE:
            v = a.split("=", 1)[1] if "=" in a else (rest[k + 1] if k + 1 < len(rest) else "")
            if a.split("=", 1)[0] in ("-e", "--editable") and not PATHY.fullmatch(v):
                pkgs = True                                  # `-e git+https://...`: not the project's own folder
            k += 1 if "=" in a else 2
            continue
        if not a.startswith("-"):
            pkgs = pkgs or not (pip and PATHY.fullmatch(a))  # `pip install .` is the project itself; a name is a package from the index
        k += 1
    if pkgs:
        tags.append("packages")
    return tags


def _merge(c: Command, d: Command) -> None:
    for x in d.danger:
        if x not in c.danger:
            c.danger.append(x)
    for p in d.writes:
        c.write(p)
    for h in d.net:
        c.host(h)
    for h in d.heads:
        c.head(h)
    for h in d.outside:
        c.out(h)
    c.opaque = c.opaque or d.opaque


def _redirects(argv, cwd, home, c):
    """Remove redirections from argv; -> (argv, [written paths]). Every operator of REDIR_OPS takes the next word (`>file` and `> file` are
    the same tokens). 0.2.11 (R6-01): `>|`, `>>|`, `&>|`, `>&file`, `<>` write their word; a redirection without a word, a punctuation token
    that is not an operator, or a zsh `>!` makes the line opaque (fail closed), never a write to a made-up file in the project."""
    out, writes, i = [], [], 0
    while i < len(argv):
        a = argv[i]
        if a in REDIR_OPS:
            t = argv[i + 1] if i + 1 < len(argv) else None
            i += 2
            if t is None or (set(t) <= PUNCT):
                c.opaque = True
                c.add("opaque", "redirection %s without a target" % a)
                continue
            if a in WORD_OPS or (a in DUP_OPS and re.fullmatch(r"\d*-?", t)):
                continue                        # heredoc delimiter / here-string / 2>&1, >&-: no file
            if t.startswith("!"):               # zsh `>! file` / `>!file` writes `file` (clobber); bash writes a file named "!..."
                c.opaque = True
                c.add("opaque", "redirection %s%s" % (a, t))
                continue
            if a in READ_OPS or a == "<&":
                _read_target(t, cwd, home, c)
            else:
                _write_target(t, cwd, home, c, writes)
        elif a.isdigit() and i + 1 < len(argv) and argv[i + 1] in REDIR_OPS:
            i += 1                              # "2" before a split ">" token (shlex splits "2>" into "2", ">")
        elif a and set(a) <= PUNCT:
            c.opaque = True                     # not an operator we know (cannot happen after _relex; kept fail-closed)
            c.add("opaque", "operator " + a)
            i += 1
        else:
            out.append(a)
            i += 1
    return out, writes


def _read_target(t, cwd, home, c):
    """0.2.11 (R6-02): `< file`: a credential file is the danger `secrets`; a path the hook cannot know (`< $F`, `< ~user/x`) is opaque."""
    e = _expand(t, cwd, home)
    if is_secret_path(t) or (e is not None and is_secret_path(_abspath(e, cwd, home))):
        c.add("secrets", _abspath(e, cwd, home) if e is not None else t)
    elif e is None:
        c.opaque = True
        c.add("opaque", "read from " + t)


def _write_target(t, cwd, home, c, writes):
    if t in SAFE_SINKS or t.startswith("/dev/fd/"):
        return
    if cwd == LOST_CWD and not t.startswith("/"):
        c.opaque = True                         # 0.2.12 (R7-02): after eval / source / a function neither the directory nor $HOME is known
        c.add("opaque", "write to %s in an unknown directory" % t)
        return
    e = _expand(t, cwd, home)                   # 0.2.11 (R6-02): $HOME / $PWD resolved; any other expansion, ~user, a glob: unknown target
    if e is None or re.search(r"[*?[]", e):
        if is_secret_path(t):
            c.add("secrets", t)
        c.opaque = True
        c.add("opaque", "write to " + t)
        return
    p = _abspath(e, cwd, home)
    writes.append(p)
    if is_secret_path(p):
        c.add("secrets", p)
    if is_git_exec_path(p):
        c.add("git-config", p)                  # 0.2.9: git would run what is written there on the next `git status` / `git diff`


def _delete_targets(ops, cwd, home, c):
    """Deleting a file is writing to its path: it is judged like any other write (outside the project -> RESOURCE)."""
    for o in ops:
        d = _expand(os.path.dirname(o) or ".", cwd, home)
        if re.search(r"[*?[]", os.path.basename(o)) and d is not None and not re.search(r"[*?[]", d):
            c.write(_abspath(d, cwd, home))                               # glob: the directory it expands in
        else:
            _write_target(o, cwd, home, c, c.writes)


def _one(name, args, cwd, home, c, via_xargs, depth, project=None):
    short, long_ = _flags(args)
    ops = _operands(args)
    paths = [o for o in ops if not re.search(r"[$`]", o)]
    uploads = [m.group(1) for a in args for m in [re.search(r"(?:^|=)@([^@\s]+)$", a)] if m]     # curl -d @file, -F f=@file
    values = [a.split("=", 1)[1] for a in args if a.startswith("-") and "=" in a]
    for o in ops + uploads + values:                      # reading, copying or uploading a credential file
        e = _expand(o, cwd, home)                         # 0.2.11: also through $HOME/${HOME}, and a symlink in the project to a key
        if is_secret_path(o) or (e is not None and (PATHLIKE.match(e) or "/" in e) and is_secret_path(_abspath(e, cwd, home))):
            c.add("secrets", _abspath(e, cwd, home) if e is not None else o)
        elif e is None and (o.startswith("~") or "/" in o or o in uploads or (name in FILE_READERS and o not in ops[:FILE_READERS[name]])):
            c.opaque = True                               # 0.2.11 (R6-02): `cat ${KEY}`, `cp $(..) x`, `less ~user/x`: a path the hook cannot
            c.add("opaque", "path from expansion: %s %s" % (name, o))   # know may be a credential -> asked as dangerous, whatever unlisted says
    for m in SECRET_ENV.finditer(" ".join(args)):
        if name in ("echo", "printf", "env", "printenv", "export", "set", "declare") or name in FETCHERS:
            c.add("secrets", "$" + m.group(1))
    if name == "printenv" and not ops:
        c.add("secrets", "whole environment")
    _network(name, args, ops, c)
    if name in CLOUD_CLIS or (name, ops[0] if ops else "") in PUBLISH:
        c.opaque = True
        c.add("opaque", "remote service CLI: " + name)
    if name in FETCHERS:                                  # curl -o FILE / --output FILE, wget -O FILE / --output-document=FILE
        flags = {"curl": ("-o", "--output"), "wget": ("-O", "--output-document")}.get(name, ())
        for k, a in enumerate(args):
            if flags and k + 1 < len(args) and (a in flags or (re.fullmatch(r"-[A-Za-z]+", a) and a.endswith(flags[0][1]))):
                if args[k + 1] != "-":                    # "-" = stdout
                    _write_target(args[k + 1], cwd, home, c, c.writes)
            elif "=" in a and a.split("=", 1)[0] in flags and a.split("=", 1)[1] != "-":
                _write_target(a.split("=", 1)[1], cwd, home, c, c.writes)
            elif len(a) > 2 and a[:2] in flags and not a.startswith("--") and a[2:] != "-":
                _write_target(a[2:], cwd, home, c, c.writes)
    if name == "rm":
        rec = bool(short & {"r", "R"}) or "--recursive" in long_
        force = "f" in short or "--force" in long_
        if rec or (force and (via_xargs or any(re.search(r"[*?]", o) for o in ops))):
            for o in (ops or ["(stdin)" if via_xargs else "(none)"]):
                c.add("rm-rf", o if re.search(r"[$`*?]", o) or o.startswith("(") else _abspath(o, cwd, home))
        else:
            _delete_targets(ops, cwd, home, c)          # a plain delete is a write to its path (rm -rf is judged as danger already)
        return
    if name in ("rmdir", "unlink", "shred", "srm", "wipe"):
        if name == "shred" or via_xargs:
            c.add("rm-rf", " ".join(ops) or name)
        _delete_targets(ops, cwd, home, c)
        return
    if name == "find" and ("-delete" in args or any(os.path.basename(a) in DELETERS for a in args)):
        c.add("rm-rf", "find " + (ops[0] if ops else "."))
        return
    if name == "git":
        _git(args, cwd, home, c)
        return
    if name in ("dd",):
        for a in args:
            if a.startswith("of="):
                tgt = a[3:]
                if tgt.startswith("/dev/") and tgt not in SAFE_SINKS:
                    c.add("disk", tgt)
                else:
                    _write_target(tgt, cwd, home, c, c.writes)
        return
    if name.startswith("mkfs") or name in ("fdisk", "parted", "wipefs", "sgdisk"):
        c.add("disk", " ".join(ops) or name)
        return
    if name in ("chmod", "chown") and ("R" in short or "--recursive" in long_) and any(_abspath(p, cwd, home) in ("/", home) for p in paths):
        c.add("rm-rf", "%s -R %s" % (name, " ".join(paths)))
        return
    if name in SHELLS:
        if "c" in short:
            i = next((k for k, a in enumerate(args) if a.startswith("-") and "c" in a[1:] and not a.startswith("--")), None)
            if i is not None and i + 1 < len(args):
                _merge(c, classify(args[i + 1], cwd, home, depth + 1, project, _budget=c.budget))
        elif via_xargs:
            c.add("opaque", name + " via xargs")
            c.opaque = True
        return
    if name == "eval" or name == "source" or name == ".":
        if name == "eval":
            _merge(c, classify(" ".join(args), cwd, home, depth + 1, project, _budget=c.budget))
        return
    if name in ("tee",):
        for p in ops:
            _write_target(p, cwd, home, c, c.writes)
        return
    if name in ("cp", "mv", "install", "ln", "rsync", "scp") and len(ops) >= 2:
        t = next((args[k + 1] for k, a in enumerate(args) if a in ("-t", "--target-directory") and k + 1 < len(args)), None)
        dest = t or ops[-1]
        if ":" not in dest or name not in ("rsync", "scp"):
            _write_target(dest, cwd, home, c, c.writes)
        if name == "mv":
            for p in ops[:-1]:
                _write_target(p, cwd, home, c, c.writes)    # moving a file away changes the source path too
        return
    if name == "sed" and ("i" in short or any(a.startswith("--in-place") for a in args)):
        for p in ops[1:]:
            _write_target(p, cwd, home, c, c.writes)
        return
    if name in ("sort", "tree", "uniq"):                     # PROPOSAL-06: read-only commands of the default list that can still write a file
        for k, a in enumerate(args):
            if name in ("sort", "tree") and a in ("-o", "--output") and k + 1 < len(args):
                _write_target(args[k + 1], cwd, home, c, c.writes)
            elif name == "sort" and a.startswith("--output="):
                _write_target(a.split("=", 1)[1], cwd, home, c, c.writes)
            elif name == "sort" and re.fullmatch(r"-[A-Za-z]*o.+", a):
                _write_target(a[a.index("o") + 1:], cwd, home, c, c.writes)
        if name == "uniq" and len(ops) >= 2:
            _write_target(ops[1], cwd, home, c, c.writes)
        return
    if name in ("touch", "mkdir", "truncate"):
        for p in ops:
            if name != "truncate" or not p.isdigit():
                _write_target(p, cwd, home, c, c.writes)
        return
    if name in ("psql", "mysql", "sqlite3", "mongo", "mongosh", "redis-cli") and any(a.upper() in ("FLUSHALL", "FLUSHDB") for a in args):
        c.add("sql-drop", " ".join(args)[:DETAIL_MAX])


def _git(args, cwd, home, c):
    i = 0
    while i < len(args) and args[i].startswith("-"):        # git -C dir, -c k=v
        i += 1 + (args[i] in ("-C", "-c", "--git-dir", "--work-tree"))
    if i >= len(args):
        return
    sub, rest = args[i], args[i + 1:]
    short, long_ = _flags(rest)
    ops = _operands(rest)
    for k, a in enumerate(rest):                             # git diff/log/show/format-patch --output=FILE, -o DIR: a write
        if a.startswith("--output=") or a.startswith("--output-directory="):
            _write_target(a.split("=", 1)[1], cwd, home, c, c.writes)
        elif a in ("--output", "--output-directory") or (a == "-o" and sub == "format-patch"):
            if k + 1 < len(rest):
                _write_target(rest[k + 1], cwd, home, c, c.writes)
    if sub == "config":                                  # 0.2.9: sets a program git runs later (core.fsmonitor, diff.*.textconv, alias.*, ...)
        key = ops[1] if ops[:1] == ["set"] and len(ops) > 1 else (ops[0] if ops else "")
        reading = short & {"l"} or long_ & {"--list", "--get", "--get-all", "--get-regexp", "--get-urlmatch", "--show-origin", "--show-scope",
                                             "--unset", "--unset-all"} or ops[:1] in (["get"], ["list"], ["unset"])
        if ops[:1] == ["edit"] or short & {"e"} or "--edit" in long_:
            c.add("git-config", "config --edit")
        elif not reading and GIT_EXEC_KEY.fullmatch(key):
            c.add("git-config", "config " + key)
    if sub == "push":
        if "f" in short or long_ & {"--force", "--force-with-lease", "--force-if-includes", "--mirror", "--delete"} or "d" in short \
                or any(o.startswith("+") or o.startswith(":") for o in ops[1:]):
            c.add("git-force-push", " ".join(ops) or "(default remote)")
    elif sub == "reset" and "--hard" in long_:
        c.add("git-destroy", "reset --hard " + " ".join(ops))
    elif sub == "clean" and ("f" in short or "--force" in long_):
        c.add("git-destroy", "clean " + " ".join(rest))
    elif sub == "checkout" and ("--" in rest and ops == ["."] or ops[:1] == ["."]) :
        c.add("git-destroy", "checkout .")
    elif sub == "branch" and ("D" in short or ("d" in short and "f" in short)):
        c.add("git-destroy", "branch -D " + " ".join(ops))
    elif sub == "filter-branch" or sub == "filter-repo" or (sub == "reflog" and ops[:1] == ["expire"]):
        c.add("git-destroy", sub)
    elif sub == "stash" and ops[:1] in (["drop"], ["clear"]):
        c.add("git-destroy", "stash " + ops[0])


def _raw_scan(cmd: str, c: Command) -> None:
    m = SQL_DROP.search(cmd)
    if m:
        c.add("sql-drop", m.group(0).strip(" ;\"'"))
    m = RAW_PIPE_SHELL.search(cmd)
    if m:
        c.add("pipe-to-shell", m.group(0))
    for seg in re.split(r"[;&\n]", cmd):                 # `curl ... | sh`: a fetch piped straight into an interpreter (linear time)
        parts = seg.split("|")
        for a, b in zip(parts, parts[1:]):
            if b and PIPE_INTO.match(b) and PIPE_FROM.search(a):
                c.add("pipe-to-shell", (a.strip() + " | " + b.strip())[:DETAIL_MAX])
                break
    if re.search(r"\b(base64|openssl\s+(enc|base64)|xxd|uudecode|gunzip|zcat|gzip\s+-\w*d)\b[^|]*\|\s*(sudo\s+)?(\S*/)?(ba|z|da|k)?sh\b", cmd, re.I):
        c.add("pipe-to-shell", "decoded data | sh")


def _network(name, args, ops, c):
    """Hosts a command talks to. A host hidden in a variable makes the line opaque (cannot be judged by domain)."""
    if name in FETCHERS or (name == "git" and ops[:1] and ops[0] in ("clone", "fetch", "pull", "push", "ls-remote", "remote", "submodule")) \
            or name in ("pip", "pip3", "npm", "npx", "yarn", "pnpm", "uv", "go", "cargo", "docker", "podman", "kubectl", "helm"):
        for a in args:
            for m in URL_RE.finditer(a):
                c.host(m.group(2).strip("[]"))
        if name in FETCHERS and not c.net:
            vals, skip = [], False                       # operands that are not values of an option (-o FILE, -H HDR, -d DATA ...)
            for a in args:
                if skip:
                    skip = False
                    continue
                if re.fullmatch(r"-[A-Za-z]*[oOdHuXTFAebcKmwxEr]", a) or a in CURL_VALUE_LONG:
                    skip = True
                    continue
                if not a.startswith("-"):
                    vals.append(a)
            bare = [o for o in vals if not URL_RE.search(o) and re.fullmatch(r"[\w.-]+\.[a-zA-Z]{2,}(:\d+)?(/\S*)?", o)]
            for o in bare:                                   # curl example.com/path (no scheme)
                c.host(re.split(r"[:/]", o, maxsplit=1)[0])
            if any(re.search(r"\$|`", o) for o in ops) and not c.net:
                c.opaque = True
                c.add("opaque", "%s to a host from a variable" % name)
    elif name in REMOTE_SHELLS:
        tgt = []
        if name in ("ssh", "mosh", "sftp", "telnet", "ftp", "nc", "ncat", "netcat"):
            skip_next = set("bcDEeFIiJLlmOopQRSWw") if name in ("ssh", "sftp") else set("pswiq")
            i = 0
            while i < len(args):
                a = args[i]
                if a.startswith("-") and len(a) > 1:
                    i += 1 + (len(a) == 2 and a[1] in skip_next)
                    continue
                tgt.append(a)
                break
        else:                                                    # scp / rsync: [user@]host:path operands
            tgt = [o.split(":", 1)[0] for o in ops if re.match(r"[^/]*:", o) and not o.startswith("/")]
        for t in tgt:
            h = t.rsplit("@", 1)[-1]
            if re.search(r"[$`]", h):
                c.opaque = True
                c.add("opaque", "%s to a host from a variable" % name)
            elif h:
                c.host(h)
